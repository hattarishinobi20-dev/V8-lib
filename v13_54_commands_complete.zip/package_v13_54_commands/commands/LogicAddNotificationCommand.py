from __future__ import annotations
from dataclasses import dataclass, field
from common import DataReference, Reader, Writer

def rd_ref(r:Reader)->DataReference:
    h,l=r.read_data_reference();return DataReference(h,l)
def wr_ref(w:Writer,x:DataReference)->None:w.write_data_reference(x.high,x.low)

class Notification:
    type_id:int=0

@dataclass
class VIntNotification(Notification):
    value:int=0
    def encode_fields(self,w):w.write_vint(self.value)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_vint())
@dataclass
class TwoVIntNotification(Notification):
    value_0:int=0;value_1:int=0
    def encode_fields(self,w):w.write_vint(self.value_0);w.write_vint(self.value_1)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_vint(),r.read_vint())
@dataclass
class FiveVIntNotification(Notification):
    values:list[int]=field(default_factory=lambda:[0]*5)
    def encode_fields(self,w):
        for x in self.values:w.write_vint(x)
    @classmethod
    def decode_fields(cls,r):return cls([r.read_vint() for _ in range(5)])
@dataclass
class ThreeVIntNotification(Notification):
    values:list[int]=field(default_factory=lambda:[0]*3)
    def encode_fields(self,w):
        for x in self.values:w.write_vint(x)
    @classmethod
    def decode_fields(cls,r):return cls([r.read_vint() for _ in range(3)])
@dataclass
class TextAndThreeVIntNotification(Notification):
    text:str|None=None;values:list[int]=field(default_factory=lambda:[0]*3)
    def encode_fields(self,w):
        w.write_string(self.text)
        for x in self.values:w.write_vint(x)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_string(),[r.read_vint() for _ in range(3)])
@dataclass
class ThreeVIntAndTextNotification(Notification):
    values:list[int]=field(default_factory=lambda:[0]*3);text:str|None=None
    def encode_fields(self,w):
        for x in self.values:w.write_vint(x)
        w.write_string(self.text)
    @classmethod
    def decode_fields(cls,r):return cls([r.read_vint() for _ in range(3)],r.read_string())
@dataclass
class TimedIntValueEntry:
    values:list[int]=field(default_factory=lambda:[0]*4)
    def encode(self,w):
        for x in self.values:w.write_vint(x)
    @classmethod
    def decode(cls,r):return cls([r.read_vint() for _ in range(4)])
@dataclass
class TimedIntListNotification(Notification):
    entries:list[TimedIntValueEntry]=field(default_factory=list)
    def encode_fields(self,w):
        w.write_vint(len(self.entries))
        for x in self.entries:x.encode(w)
    @classmethod
    def decode_fields(cls,r):return cls([TimedIntValueEntry.decode(r) for _ in range(r.read_vint())])
@dataclass
class NotificationP(VIntNotification):
    type_id=80
@dataclass
class ChronosFileNotification(Notification):
    value_0:int=0;value_1:int=0;value_2:int=0;value_3:int=0
    def encode_fields(self,w):
        w.write_vint(self.value_0);w.write_vint(self.value_1);w.write_vint(self.value_2);w.write_vint(self.value_3)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_vint(),r.read_vint(),r.read_vint(),r.read_vint())
@dataclass
class NotificationS(Notification):
    text_0:str|None=None;text_1:str|None=None;text_2:str|None=None;file_entry:ChronosFileNotification=field(default_factory=ChronosFileNotification);tail:str|None=None;value_56:int=0
    type_id=83
    def encode_fields(self,w):
        w.write_string(self.text_0);w.write_string(self.text_1);w.write_string(self.text_2);self.file_entry.encode_fields(w);w.write_string(self.tail);w.write_vint(self.value_56)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_string(),r.read_string(),r.read_string(),ChronosFileNotification.decode_fields(r),r.read_string(),r.read_vint())
@dataclass
class NotificationW(Notification):
    tail:str|None=None
    type_id=87
    def encode_fields(self,w):w.write_string(self.tail)
    @classmethod
    def decode_fields(cls,r):return cls(r.read_string())
@dataclass
class NotificationL(Notification):
    type_id=76
    def encode_fields(self,w):
        # O slot de encode do tipo 76 não grava campos após o type_id.
        return
    @classmethod
    def decode_fields(cls,r):return cls()

# Type IDs are the values returned by the notification vtables in sub_4572EC.
class NotificationH(VIntNotification):type_id=72
class NotificationI(VIntNotification):type_id=73
class NotificationJ(TwoVIntNotification):type_id=74
class NotificationK(TwoVIntNotification):type_id=75
class NotificationM(FiveVIntNotification):type_id=77
class NotificationN(TwoVIntNotification):type_id=78
class NotificationO(TimedIntListNotification):type_id=79
class NotificationQ(VIntNotification):type_id=81
class NotificationR(TextAndThreeVIntNotification):type_id=82
class NotificationT(TwoVIntNotification):type_id=84
class NotificationU(ThreeVIntAndTextNotification):type_id=85
class NotificationV(VIntNotification):type_id=86
class NotificationX(TwoVIntNotification):type_id=88
class NotificationY(TwoVIntNotification):type_id=89
class NotificationZ(ThreeVIntNotification):type_id=90
class NotificationBracketOpen(TwoVIntNotification):type_id=91
class NotificationBackslash(ThreeVIntNotification):type_id=92
class NotificationBracketClose(TwoVIntNotification):type_id=93
class NotificationCaret(VIntNotification):type_id=94

# The remaining factory cases use dedicated ByteStream-derived notification classes.

NOTIFICATION_TYPES={x.type_id:x for x in (NotificationH,NotificationI,NotificationJ,NotificationK,NotificationL,NotificationM,NotificationN,NotificationO,NotificationP,NotificationQ,NotificationR,NotificationS,NotificationT,NotificationU,NotificationV,NotificationW,NotificationX,NotificationY,NotificationZ,NotificationBracketOpen,NotificationBackslash,NotificationBracketClose,NotificationCaret)}

@dataclass
class LogicAddNotificationCommand:
    id:int=206
    tick_when_given:int=0
    base_value_8:int=0
    base_value_12:int=0
    base_global_id:DataReference=field(default_factory=DataReference)
    notification:Notification|None=None
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_boolean(self.notification is not None)
        if self.notification is not None:
            w.write_vint(self.notification.type_id);self.notification.encode_fields(w)
        w.write_vint(self.tick_when_given);w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls()
        if r.read_boolean():
            tid=r.read_vint();kind=NOTIFICATION_TYPES.get(tid)
            if kind is None:raise ValueError(f'notification type unsupported: {tid}')
            o.notification=kind.decode_fields(r)
        o.tick_when_given=r.read_vint();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);return o
