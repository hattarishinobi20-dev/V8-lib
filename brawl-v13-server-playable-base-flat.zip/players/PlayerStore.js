const crypto = require('crypto')
const Player = require('./Player')

class PlayerStore {
  constructor (data, database) {
    this.data = data
    this.database = database
    this.players = new Map()
    this.sessions = new Map()
  }

  getOrCreate (id, name = 'Player') {
    const key = String(id)
    if (!this.players.has(key)) {
      const player = new Player({ id: Number(id), name, data: this.data })
      this.database.ensurePlayer(player)
      this.players.set(key, player)
    }
    return this.players.get(key)
  }

  createSession (player) {
    const token = crypto.randomBytes(16).toString('hex')
    player.sessionToken = token
    this.sessions.set(token, player)
    this.database.saveSession(token, player.id)
    return token
  }

  fromSession (token) {
    if (!token) return null
    const local = this.sessions.get(String(token))
    if (local) return local
    const playerId = this.database.playerIdFromSession(String(token))
    if (!playerId) return null
    const player = this.getOrCreate(playerId)
    player.sessionToken = String(token)
    this.sessions.set(String(token), player)
    return player
  }

  attach (player, client, token = null) {
    const session = token || this.createSession(player)
    player.login(client, session)
    this.sessions.set(session, player)
    this.database.saveSession(session, player.id)
    this.database.savePlayer(player)
    return session
  }

  save (player) {
    if (player) this.database.savePlayer(player)
  }

  detach (client) {
    for (const player of this.players.values()) {
      if (player.client === client) {
        this.database.savePlayer(player)
        player.disconnect()
      }
    }
  }
}

module.exports = PlayerStore
