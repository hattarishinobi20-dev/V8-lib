from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high, x.low)

@dataclass
class QuestEntry:
    values:list[int]=field(default_factory=lambda:[0]*10); flag_40:bool=False;flag_41:bool=False;global_id:DataReference=field(default_factory=DataReference);value_48:int=0;value_52:int=0
    def encode(self,w:Writer)->None:
        for x in self.values:w.write_vint(x)
        w.write_boolean(self.flag_40);w.write_boolean(self.flag_41);wr_ref(w,self.global_id);w.write_vint(self.value_48);w.write_vint(self.value_52)
    @classmethod
    def decode(cls,r:Reader):return cls([r.read_vint() for _ in range(10)],r.read_boolean(),r.read_boolean(),rd_ref(r),r.read_vint(),r.read_vint())
@dataclass
class LogicHeroWinQuestsChangedCommand:
    id:int=220;base_value_8:int=0;base_value_12:int=0;base_global_id:DataReference=field(default_factory=DataReference);tick_when_given:int=0;quests:list[QuestEntry]=field(default_factory=list)
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_boolean(bool(self.quests));
        if self.quests:
            w.write_vint(len(self.quests))
            for x in self.quests:x.encode(w)
        w.write_vint(self.tick_when_given);w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls();o.quests=[QuestEntry.decode(r) for _ in range(r.read_vint())] if r.read_boolean() else [];o.tick_when_given=r.read_vint();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);return o
