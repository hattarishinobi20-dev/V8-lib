from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high, x.low)

@dataclass
class OfferItem:
    value_0:int=0;value_4:int=0;global_id:DataReference=field(default_factory=DataReference);value_12:int=0
    def encode(self,w:Writer)->None:w.write_vint(self.value_0);w.write_vint(self.value_4);wr_ref(w,self.global_id);w.write_vint(self.value_12)
    @classmethod
    def decode(cls,r:Reader):return cls(r.read_vint(),r.read_vint(),rd_ref(r),r.read_vint())
@dataclass
class OfferEntry:
    items:list[OfferItem]=field(default_factory=list);value_16:int=0;value_12:int=0;value_20:int=0;value_24:int=0;value_28:int=0;flag_32:bool=False;value_36:int=0;flag_44:bool=False;value_56:int=0;text:str|None=None;flag_64:bool=False;value_60:int=0;flag_65:bool=False
    def encode(self,w:Writer)->None:
        w.write_vint(len(self.items));[x.encode(w) for x in self.items]
        for x in (self.value_16,self.value_12,self.value_20,self.value_24,self.value_28):w.write_vint(x)
        w.write_boolean(self.flag_32);w.write_vint(self.value_36);w.write_boolean(self.flag_44);w.write_vint(self.value_56);w.write_string(self.text);w.write_boolean(self.flag_64);w.write_vint(self.value_60);w.write_boolean(self.flag_65)
    @classmethod
    def decode(cls,r:Reader):
        o=cls();o.items=[OfferItem.decode(r) for _ in range(r.read_vint())];o.value_16,o.value_12,o.value_20,o.value_24,o.value_28=[r.read_vint() for _ in range(5)];o.flag_32=r.read_boolean();o.value_36=r.read_vint();o.flag_44=r.read_boolean();o.value_56=r.read_vint();o.text=r.read_string();o.flag_64=r.read_boolean();o.value_60=r.read_vint();o.flag_65=r.read_boolean();return o
@dataclass
class LogicOffersChangedCommand:
    id:int=211;base_value_8:int=0;base_value_12:int=0;base_global_id:DataReference=field(default_factory=DataReference);offers:list[OfferEntry]=field(default_factory=list)
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);w.write_vint(len(self.offers));[x.encode(w) for x in self.offers];return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);o.offers=[OfferEntry.decode(r) for _ in range(r.read_vint())];return o
