const V13Message = require('../../protocol/V13Message')
const ServerHelloMessage = require('../Server/ServerHelloMessage')

class ClientHelloMessage extends V13Message {
  constructor (bytes = null, client = null, context = null) {
    super(bytes, client, context)
    this.id = 10100
    this.version = 0
  }

  decode () {
    return this.decodeOpaque()
  }

  async process () {
    await new ServerHelloMessage(this.client, this.context).send()
    if (this.client && typeof this.client.startKeepAlive === 'function') {
      this.client.startKeepAlive((this.context && this.context.keepAliveIntervalMs) || 30000)
    }
    return this
  }
}

module.exports = ClientHelloMessage
