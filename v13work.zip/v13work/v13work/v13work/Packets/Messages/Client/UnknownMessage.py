from Utils.Reader import BSMessageReader


class UnknownMessage(BSMessageReader):
    def __init__(self, client, player, initial_bytes):
        super().__init__(initial_bytes)

    def decode(self):
        pass

    def process(self, crypter):
        pass