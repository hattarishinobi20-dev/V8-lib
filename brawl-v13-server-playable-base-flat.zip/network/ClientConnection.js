const V13ByteStream = require('../protocol/V13ByteStream')
const KeepAliveServerMessage = require('../messages/Server/KeepAliveServerMessage')

class ClientConnection extends V13ByteStream {
  constructor (server, socket) {
    super()
    this.server = server
    this.socket = socket
    this.player = null
    this.playerId = null
    this.sessionToken = null
    this.input = Buffer.alloc(0)
    this.remoteAddress = socket.remoteAddress
    this.keepAliveTimer = null
    socket.on('data', (chunk) => this.receive(chunk))
    socket.on('close', () => this.close())
    socket.on('error', (error) => server.log.warn(`socket ${this.remoteAddress}: ${error.message}`))
  }

  write (data) { return this.socket.write(data) }

  log (message) { this.server.log.debug(`[${this.remoteAddress}] ${message}`) }

  startKeepAlive (intervalMs = 30000) {
    if (this.keepAliveTimer) return
    const delay = Math.max(1000, Number(intervalMs) || 30000)
    this.keepAliveTimer = setInterval(() => {
      if (!this.socket.destroyed) {
        try {
          new KeepAliveServerMessage(this, this.server.context).send()
        } catch (error) {
          this.server.log.warn(`keepalive falhou para ${this.remoteAddress}: ${error.message}`)
        }
      }
    }, delay)
    if (this.keepAliveTimer.unref) this.keepAliveTimer.unref()
  }

  stopKeepAlive () {
    if (!this.keepAliveTimer) return
    clearInterval(this.keepAliveTimer)
    this.keepAliveTimer = null
  }

  receive (chunk) {
    this.input = Buffer.concat([this.input, chunk])
    const trailer = Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0])
    while (this.input.length >= 7) {
      const id = this.input.readUInt16BE(0)
      const length = this.input.readUIntBE(2, 3)
      const version = this.input.readUInt16BE(5)
      const frameLength = 7 + length + trailer.length
      if (this.input.length < frameLength) return
      const payload = this.input.slice(7, 7 + length)
      const receivedTrailer = this.input.slice(7 + length, frameLength)
      this.input = this.input.slice(frameLength)
      if (!receivedTrailer.equals(trailer)) {
        this.server.log.warn(`trailer inválido no packet ${id}`)
        this.socket.destroy()
        return
      }
      this.server.receivePacket(this, id, version, payload)
    }
  }

  close () {
    this.stopKeepAlive()
    this.server.players.detach(this)
    this.server.clients.delete(this)
    this.server.log.info(`cliente desconectado: ${this.remoteAddress}`)
  }
}

module.exports = ClientConnection
