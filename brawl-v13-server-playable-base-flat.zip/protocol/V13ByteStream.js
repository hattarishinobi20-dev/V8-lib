const PiranhaMessage = require('./PiranhaMessage')

/**
 * Compatibilidade v13 sobre o ByteStream real do nodebrawl-core.
 * O encoder do core segue o formato SC de VInt, mas o readVInt/readBoolean
 * distribuído no core não é o inverso do encoder. As escritas continuam
 * herdadas diretamente do core; apenas as leituras incompatíveis são corrigidas.
 */
class V13ByteStream extends PiranhaMessage {
  readVInt () {
    this.bitOffset = 0
    if (this.offset >= this.buffer.length) throw new RangeError('VInt fora do payload')
    const first = this.buffer[this.offset++]
    let result = first & 0x3f
    let shift = 6
    if ((first & 0x80) !== 0) {
      let byte
      do {
        if (this.offset >= this.buffer.length) throw new RangeError('VInt truncado')
        byte = this.buffer[this.offset++]
        result |= (byte & 0x7f) << shift
        shift += 7
      } while ((byte & 0x80) !== 0 && shift < 35)
    }
    if ((first & 0x40) !== 0) {
      if (shift < 32) result |= (-1 << shift)
    }
    return result | 0
  }

  readBoolean () {
    if (this.bitOffset === 0) {
      if (this.offset >= this.buffer.length) throw new RangeError('Boolean fora do payload')
      this._booleanByte = this.buffer[this.offset++]
    }
    const value = (this._booleanByte & (1 << this.bitOffset)) !== 0
    this.bitOffset = (this.bitOffset + 1) & 7
    return value
  }
}

module.exports = V13ByteStream
