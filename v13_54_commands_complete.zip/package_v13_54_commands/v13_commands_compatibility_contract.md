# Contrato canônico de compatibilidade dos commands v13

Fonte: `libv13.so.i64` analisado no IDA Pro.

Quantidade: **54 commands**.

| ID | Command | Offsets | Encode | Decode |
|---:|---|---|---|---|
| 201 | `LogicChangeAvatarNameCommand` | `28,44` | `0x524290` | `0x395be0` |
| 202 | `LogicDiamondsAddedCommand` | `28,32,36,40,44` | `0x113e38` | `0x928e8` |
| 203 | `LogicGiveDeliveryItemsCommand` | `8` | `0xd9194` | `0x4794e4` |
| 204 | `LogicDayChangedCommand` | `28` | `0x43a218` | `0x1d5a9c` |
| 205 | `LogicDecreaseHeroScoreCommand` | `28,40` | `0x66b1bc` | `0x5f2798` |
| 206 | `LogicAddNotificationCommand` | `28` | `0x3f334c` | `0x270850` |
| 207 | `LogicChangeResourcesCommand` | `28,32` | `0x52015c` | `0x3ab1d8` |
| 208 | `LogicTransactionsRevokedCommand` | `28` | `0x575750` | `0x3df540` |
| 209 | `LogicKeyPoolChangedCommand` | `28,32` | `0x1a1d38` | `0x3d63f4` |
| 210 | `LogicIAPChangedCommand` | `28,32` | `0x17838c` | `0x55aa0c` |
| 211 | `LogicOffersChangedCommand` | `28` | `0x61d34c` | `0x3f83fc` |
| 212 | `LogicPlayerDataChangedCommand` | `28` | `0x4f7b1c` | `0x479dec` |
| 213 | `LogicInviteBlockingChangedCommand` | `28` | `0x193564` | `0x56b3fc` |
| 214 | `LogicGemNameChangeStateChangedCommand` | `28,32` | `0x1d01e4` | `0x61ed20` |
| 215 | `LogicSetSupportedCreatorCommand` | `28` | `0x69aadc` | `0x699a2c` |
| 216 | `LogicCooldownExpiredCommand` | `28,32` | `0x412584` | `0x494a8c` |
| 217 | `LogicProLeagueSeasonChangedCommand` | `28,32` | `0x527778` | `0x61e5d0` |
| 218 | `LogicBrawlPassSeasonChangedCommand` | `28,32` | `0xea81c` | `0x445b90` |
| 219 | `LogicBrawlPassUnlockedCommand` | `28` | `0x2a1560` | `0x1ab69c` |
| 220 | `LogicHeroWinQuestsChangedCommand` | `28` | `0x47907c` | `0x1dd6ac` |
| 221 | `LogicTeamChatMuteStateChangedCommand` | `28` | `0x44a7b8` | `0x5e23f8` |
| 500 | `LogicGatchaCommand` | `24` | `0x44b58c` | `0x1cefb4` |
| 503 | `LogicClaimDailyRewardCommand` | `24,28` | `0x10d0bc` | `0x65a714` |
| 504 | `LogicSendAllianceMailCommand` | `24,28` | `0xa980c` | `0x8c984` |
| 505 | `LogicSetPlayerThumbnailCommand` | `24` | `0x503a2c` | `0x2efa60` |
| 506 | `LogicSelectSkinCommand` | `24` | `0x1bd29c` | `0x395ad0` |
| 507 | `LogicUnlockSkinCommand` | `24` | `0x44b098` | `0x35aeac` |
| 508 | `LogicChangeControlModeCommand` | `24` | `0x2df86c` | `0x3e343c` |
| 509 | `LogicPurchaseDoubleCoinsCommand` | `` | `0xef5b4` | `0xf214c` |
| 511 | `LogicHelpOpenedCommand` | `` | `0x1734c0` | `0x2edf7c` |
| 512 | `LogicToggleInGameHintsCommand` | `` | `0x550c20` | `0x55eb3c` |
| 514 | `LogicDeleteNotificationCommand` | `24,28` | `0xe9dac` | `0x2847c8` |
| 515 | `LogicClearShopTickersCommand` | `` | `0x10c9bc` | `0x120764` |
| 519 | `LogicPurchaseOfferCommand` | `24,28` | `0x249060` | `0xa998c` |
| 520 | `LogicLevelUpCommand` | `24` | `0x173878` | `0x18ddb8` |
| 521 | `LogicPurchaseHeroLvlUpMaterialCommand` | `24` | `0x2de780` | `0x1f161c` |
| 522 | `LogicHeroSeenCommand` | `24,28` | `0x1de920` | `0x2c4120` |
| 523 | `LogicClaimAdRewardCommand` | `24,28` | `0x259688` | `0x5d7e8` |
| 524 | `LogicVideoStartedCommand` | `24` | `0x61de14` | `0x22ced0` |
| 525 | `LogicSelectCharacterCommand` | `24` | `0x10e578` | `0x4be5e8` |
| 526 | `LogicUnlockFreeSkinsCommand` | `` | `0x362748` | `0x1a5998` |
| 527 | `LogicSetPlayerNameColorCommand` | `24` | `0x4dd640` | `0x28b22c` |
| 528 | `LogicViewInboxNotificationCommand` | `24,28` | `0x18c3d0` | `0x3d823c` |
| 529 | `LogicSelectStarPowerCommand` | `24` | `0x688260` | `0x4a0e60` |
| 530 | `LogicSetPlayerAgeCommand` | `24` | `0x1f99a0` | `0x1c16d8` |
| 531 | `LogicCancelPurchaseOfferCommand` | `24,28` | `0x1aa77c` | `0x4fd1c4` |
| 532 | `LogicItemSeenCommand` | `24` | `0x384384` | `0x262b3c` |
| 533 | `LogicQuestsSeenCommand` | `` | `0x62037c` | `0x5ec3cc` |
| 534 | `LogicPurchaseBrawlPassCommand` | `24,28` | `0x473a58` | `0x5ba310` |
| 535 | `LogicClaimTailRewardCommand` | `24,28` | `0x4199d4` | `0x43c830` |
| 536 | `LogicPurchaseBrawlPassProgressCommand` | `24` | `0x93420` | `0x261478` |
| 537 | `LogicVanityItemSeenCommand` | `24` | `0x4e0630` | `0x208298` |
| 538 | `LogicSelectEmoteCommand` | `24` | `0x433384` | `0x5679c8` |
| 1000 | `LogicDebugCommand` | `8` | `0x17e524` | `0x5158c` |
