"""Commands lógicos internos da versão Brawl Stars v13."""
