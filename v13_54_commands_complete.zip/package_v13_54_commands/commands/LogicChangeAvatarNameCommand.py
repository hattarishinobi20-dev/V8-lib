from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer




def _read_data_reference(r: Reader) -> DataReference:
    high, low = r.read_data_reference()
    return DataReference(high, low)

def _write_data_reference(w: Writer, value: DataReference | tuple[int, int] | None) -> None:
    if value is None:
        w.write_data_reference(0, -1)
    elif isinstance(value, DataReference):
        w.write_data_reference(value.high, value.low)
    else:
        w.write_data_reference(int(value[0]), int(value[1]))


@dataclass
class LogicChangeAvatarNameCommand:
    """Logic command v13 ID 201; fields and codec order extracted from IDA vtable slots."""
    id: int = 201
    tick_when_given: int = 0
    base_value_8: int = 0
    base_value_12: int = 0
    base_global_id: DataReference = field(default_factory=DataReference)
    avatar_name: str | None = None
    value_44: int = 0

    @classmethod
    def get_command_type(cls) -> int:
        return cls.id

    def _encode_base(self, w: Writer) -> None:
        w.write_vint(self.base_value_12)
        w.write_vint(self.base_value_8)
        _write_data_reference(w, self.base_global_id)

    @classmethod
    def _decode_base(cls, obj, r: Reader):
        obj.base_value_12 = r.read_vint()
        obj.base_value_8 = r.read_vint()
        obj.base_global_id = _read_data_reference(r)

    def encode(self) -> bytes:
        w = Writer()
        w.write_string(self.avatar_name)
        w.write_vint(self.value_44)
        w.write_vint(self.tick_when_given)
        self._encode_base(w)
        return w.bytes()

    @classmethod
    def decode(cls, payload: bytes):
        r = Reader(payload)
        obj = cls()
        obj.avatar_name = r.read_string()
        obj.value_44 = r.read_vint()
        obj.tick_when_given = r.read_vint()
        cls._decode_base(obj, r)
        return obj
