const net = require('net')
const path = require('path')
const DataRepository = require('../database/DataRepository')
const SqliteStore = require('../database/SqliteStore')
const PlayerStore = require('../players/PlayerStore')
const PacketFactory = require('../protocol/PacketFactory')
const MessageRouter = require('../handlers/MessageRouter')
const RoomManager = require('../rooms/RoomManager')
const BattleManager = require('../battle/BattleManager')
const ClientConnection = require('../network/ClientConnection')

function makeLogger () {
  const stamp = () => new Date().toISOString()
  return {
    info: (message) => console.log(`[${stamp()}] INFO ${message}`),
    warn: (message) => console.warn(`[${stamp()}] WARN ${message}`),
    error: (message) => console.error(`[${stamp()}] ERROR ${message}`),
    debug: (message) => { if (process.env.DEBUG === '1') console.log(`[${stamp()}] DEBUG ${message}`) }
  }
}

class V13Server {
  constructor ({ host = process.env.HOST || '0.0.0.0', port = Number(process.env.PORT || 9339), databaseFile } = {}) {
    this.host = host
    this.port = port
    this.log = makeLogger()
    this.context = { version: 'v13' }
    this.data = new DataRepository()
    this.database = new SqliteStore(databaseFile)
    this.players = new PlayerStore(this.data, this.database)
    this.factory = new PacketFactory()
    this.rooms = new RoomManager(this)
    this.battles = new BattleManager(this)
    this.router = new MessageRouter(this)
    this.clients = new Set()
    this.nextId = 1000
    this.socket = null
  }

  nextPlayerId () { return this.nextId++ }

  receivePacket (client, id, version, payload) {
    const record = this.factory.get(id)
    if (!record) {
      this.log.warn(`packet desconhecido id=${id} version=${version} length=${payload.length}`)
      return
    }
    try {
      const packet = this.factory.createInbound(id, payload, client, { version, server: this })
      if (!packet) return
      packet.decode()
      Promise.resolve(this.router.handle(packet)).catch((error) => {
        this.log.error(`handler ${record.name}: ${error.stack || error.message}`)
        if (client.socket.destroyed) return
        client.socket.destroy(error)
      })
    } catch (error) {
      this.log.error(`decode ${record.name}: ${error.stack || error.message}`)
      client.socket.destroy()
    }
  }

  start () {
    this.socket = net.createServer((socket) => {
      const client = new ClientConnection(this, socket)
      this.clients.add(client)
      this.log.info(`cliente conectado: ${client.remoteAddress}`)
    })
    this.socket.on('error', (error) => this.log.error(`server socket: ${error.stack || error.message}`))
    this.socket.listen(this.port, this.host, () => {
      this.log.info(`Brawl v13 server ouvindo em ${this.host}:${this.port}`)
      this.log.info(`assets v13: ${JSON.stringify(this.data.summary())}`)
      this.log.info(`registry: ${this.factory.coverage().length} packets`)
    })
    return this
  }

  async close () {
    for (const client of this.clients) client.socket.destroy()
    if (this.socket) await new Promise((resolve) => this.socket.close(resolve))
    this.database.close()
  }
}

if (require.main === module) {
  const server = new V13Server()
  server.start()
  const shutdown = async () => { try { await server.close() } finally { process.exit(0) } }
  process.once('SIGINT', shutdown)
  process.once('SIGTERM', shutdown)
}

module.exports = V13Server
