const assert = require('assert')
const fs = require('fs')
const net = require('net')
const os = require('os')
const path = require('path')
const V13Server = require('../server/index')
const SqliteStore = require('../database/SqliteStore')
const DataRepository = require('../database/DataRepository')
const PlayerStore = require('../players/PlayerStore')

const TRAILER = Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0])

function frame (id, payload = Buffer.alloc(0), version = 0) {
  const header = Buffer.alloc(7)
  header.writeUInt16BE(id, 0)
  header.writeUIntBE(payload.length, 2, 3)
  header.writeUInt16BE(version, 5)
  return Buffer.concat([header, payload, TRAILER])
}

function parseFrames (state, chunk) {
  state.input = Buffer.concat([state.input, chunk])
  while (state.input.length >= 14) {
    const length = state.input.readUIntBE(2, 3)
    const total = 7 + length + TRAILER.length
    if (state.input.length < total) return
    const id = state.input.readUInt16BE(0)
    const version = state.input.readUInt16BE(5)
    const payload = state.input.slice(7, 7 + length)
    assert.deepStrictEqual(state.input.slice(7 + length, total), TRAILER)
    state.frames.push({ id, version, payload })
    state.input = state.input.slice(total)
  }
}

function waitFor (predicate, timeoutMs = 4000) {
  const started = Date.now()
  return new Promise((resolve, reject) => {
    const tick = () => {
      if (predicate()) return resolve()
      if (Date.now() - started > timeoutMs) return reject(new Error('timeout aguardando resposta TCP'))
      setTimeout(tick, 10)
    }
    tick()
  })
}

async function run () {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'brawl-v13-tcp-'))
  const databaseFile = path.join(root, 'server.sqlite3')
  const server = new V13Server({ host: '127.0.0.1', port: 0, databaseFile })
  server.context.keepAliveIntervalMs = 60000
  server.start()
  await new Promise((resolve, reject) => {
    server.socket.once('listening', resolve)
    server.socket.once('error', reject)
  })

  const address = server.socket.address()
  const state = { input: Buffer.alloc(0), frames: [] }
  const socket = net.connect(address.port, '127.0.0.1')
  socket.on('data', (chunk) => parseFrames(state, chunk))
  await new Promise((resolve, reject) => {
    socket.once('connect', resolve)
    socket.once('error', reject)
  })

  // ClientHello: fragmentação antes do header completo e no trailer.
  const hello = frame(10100)
  socket.write(hello.slice(0, 3))
  socket.write(hello.slice(3, 10))
  socket.write(hello.slice(10))
  await waitFor(() => state.frames.some((item) => item.id === 20100))
  const serverHello = state.frames.find((item) => item.id === 20100)
  assert.strictEqual(serverHello.payload.length, 28)
  assert.strictEqual(serverHello.payload.readInt32BE(0), 24)
  assert.deepStrictEqual(serverHello.payload.slice(4), Buffer.alloc(24, 1))

  // TitanLogin mínimo: o codec de entrada v13 atual é opaco e aceita payload vazio.
  const login = frame(10101)
  socket.write(login.slice(0, 5))
  socket.write(login.slice(5, 12))
  socket.write(login.slice(12))
  await waitFor(() => state.frames.some((item) => item.id === 20104) && state.frames.some((item) => item.id === 24101))
  assert.ok(state.frames.find((item) => item.id === 20104).payload.length > 0)
  assert.ok(state.frames.find((item) => item.id === 24101).payload.length > 100)

  const connection = [...server.clients][0]
  assert.ok(connection.player)
  assert.strictEqual(connection.player.id, 1000)
  const sessionToken = connection.player.sessionToken
  assert.ok(sessionToken)

  // ClientHome/GoHome v13 (14101) retorna a home atual e exercita o roteador.
  socket.write(frame(14101))
  await waitFor(() => state.frames.filter((item) => item.id === 24101).length >= 2)

  socket.end()
  await new Promise((resolve) => socket.once('close', resolve))
  await server.close()

  const database = new SqliteStore(databaseFile)
  const data = new DataRepository()
  const players = new PlayerStore(data, database)
  const restored = players.fromSession(sessionToken)
  assert.ok(restored)
  assert.strictEqual(restored.id, 1000)
  database.close()
  console.log('tcp-playable-test: ok')
}

run().catch((error) => {
  console.error(error.stack || error.message)
  process.exitCode = 1
})
