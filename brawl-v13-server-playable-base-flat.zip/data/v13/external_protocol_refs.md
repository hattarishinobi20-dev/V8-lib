# Referências públicas consultadas durante a base jogável v13

1. **bs-proxy/bs-messages** — https://github.com/bs-proxy/bs-messages
   O README descreve PDUs com identificador e payload, BOOLEAN bit-packed, INT big-endian, RRSINT32/RRSLONG e STRING com comprimento. Também documenta ZIP_STRING como comprimento inteiro, comprimento descompactado little-endian e conteúdo zlib.

2. **Definição pública antiga de LoginOk** — https://raw.githubusercontent.com/bs-proxy/bs-messages/master/server/LoginOk.json
   Confirma o ID 20104 e a sequência inicial de userId, homeId, passToken, strings de recursos e versões; a implementação atual, porém, segue o pseudocódigo específico da libv13 do IDA.

3. **tailsjs/nodebrawl-core** — https://github.com/tailsjs/nodebrawl-core
   Confirma que o nodebrawl-core é uma base de servidor/core em JavaScript e que a implementação de mensagens e lógica é responsabilidade do projeto derivado.

4. **tailsjs/nodebrawl-client** — https://github.com/tailsjs/nodebrawl-client
   Confirma o uso do nodebrawl-core como base de um cliente JavaScript e a existência de ByteStream/Protocol como abstrações centrais.

Observação: essas referências são auxiliares. A fonte de verdade da compatibilidade v13 continua sendo `data/v13/ida_all_v13_codecs.json` e a referência local `own_home_data_message_v13.py`.
