const V13Message = require('../../protocol/V13Message')

/**
 * LoginOk v13 (20104), traduzido de sub_3B7A14/sub_288808.
 *
 * Os dois primeiros campos são LogicLongs; os campos que o IDA mostra em
 * sub_5006AC/sub_DD380 usam o VInt do ByteStream do nodebrawl-core. As listas
 * nulas são representadas pelo contador -1, exatamente como o branch nulo do
 * pseudocódigo nativo.
 */
function writeCompressedStringEmpty (stream) {
  // LogicCompressedString::encode recebe uma string vazia no fluxo inicial.
  // Para a string vazia, o encoder nativo emite o sentinel de comprimento zero.
  stream.writeInt(0)
}

function writeStringList (stream, values) {
  if (values == null) {
    stream.writeVInt(-1)
    return
  }
  stream.writeVInt(values.length)
  for (const value of values) stream.writeString(value == null ? '' : String(value))
}

function playerIdLong (player) {
  return [0, Number(player && player.id) || 0]
}

class LoginOkMessage extends V13Message {
  constructor (client = null, context = null) {
    super(null, client, context)
    this.id = 20104
    this.version = 0
  }

  encode () {
    const player = this.client && this.client.player
    const login = (this.context && this.context.login) || {}
    const account = playerIdLong(player)
    const token = player && player.sessionToken ? String(player.sessionToken) : ''

    // a1 + 80 and a1 + 84: account/home LogicLongs.
    this.writeLogicLong(account[0], account[1])
    this.writeLogicLong(account[0], account[1])

    // String fields at offsets 88, 92 and 96.
    this.writeString(token)
    this.writeString('')
    this.writeString('')

    // VInts at offsets 108, 112 and 116, followed by the environment string.
    this.writeVInt(Number(login.majorVersion ?? 13))
    this.writeVInt(Number(login.contentVersion ?? 0))
    this.writeVInt(Number(login.serverBuild ?? 0))
    this.writeString(String(login.environment ?? 'dev'))

    // Session/account counters at offsets 124, 128 and 132.
    this.writeVInt(Number(login.sessionCount ?? 0))
    this.writeVInt(Number(login.playTimeSeconds ?? 0))
    this.writeVInt(Number(login.daysSinceStartedPlaying ?? 0))

    // Remaining strings and counters, in the exact native write order.
    this.writeString(String(login.facebookAppId ?? ''))
    this.writeString(String(login.serverTime ?? ''))
    this.writeString(String(login.accountCreatedDate ?? ''))
    this.writeVInt(Number(login.startupCooldownSeconds ?? 0))
    this.writeString(String(login.googleServiceId ?? ''))
    this.writeString(String(login.loginCountry ?? ''))
    this.writeString(String(login.kunlunId ?? ''))
    this.writeVInt(Number(login.tier ?? 0))
    this.writeString(String(login.tencentId ?? ''))

    // Content URL collections (offsets 168 and 172).
    writeStringList(this, login.gameAssetsUrls ?? null)
    writeStringList(this, login.eventAssetsUrls ?? null)

    // Account deletion timer and LogicCompressedString token.
    this.writeVInt(Number(login.secondsUntilAccountDeletion ?? 0))
    writeCompressedStringEmpty(this)

    // IDA writes the first flag directly and the inverse of the second field.
    this.writeBoolean(Boolean(login.supercellLogoutAllDevicesAllowed ?? true))
    this.writeBoolean(Boolean(login.supercellIdEligible ?? false))

    // Final strings at offsets 160, 192 and 164.
    this.writeString(String(login.lineId ?? ''))
    this.writeString(String(login.sessionId ?? ''))
    this.writeString(String(login.kakaoId ?? ''))

    return this.buffer
  }
}

module.exports = LoginOkMessage
