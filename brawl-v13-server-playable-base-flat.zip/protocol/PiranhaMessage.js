// Exportação explícita da abstração original do nodebrawl-core.
module.exports = require('../vendor-nodebrawl-core/Protocol/PiranhaMessage')
