from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high, x.low)

@dataclass
class DeliveryItem:
    value_0:int=0; global_4:DataReference=field(default_factory=DataReference); value_8:int=0
    global_12:DataReference=field(default_factory=DataReference); global_16:DataReference=field(default_factory=DataReference); global_20:DataReference=field(default_factory=DataReference); value_24:int=0
    def encode(self,w:Writer)->None:
        w.write_vint(self.value_4); wr_ref(w,self.global_4); w.write_vint(self.value_0); wr_ref(w,self.global_12); wr_ref(w,self.global_16); wr_ref(w,self.global_20); w.write_vint(self.value_24)
    @classmethod
    def decode(cls,r:Reader):
        return cls(r.read_vint(),rd_ref(r),r.read_vint(),rd_ref(r),rd_ref(r),rd_ref(r),r.read_vint())
@dataclass
class ForcedDrops:
    value_0:int=0; items:list[DeliveryItem]=field(default_factory=list)
    def encode(self,w:Writer)->None:
        w.write_vint(self.value_0); w.write_vint(len(self.items))
        for x in self.items:x.encode(w)
    @classmethod
    def decode(cls,r:Reader):
        a=r.read_vint(); n=r.read_vint(); return cls(a,[DeliveryItem.decode(r) for _ in range(n)])
@dataclass
class LogicGiveDeliveryItemsCommand:
    id:int=203; base_value_8:int=0; base_value_12:int=0; base_global_id:DataReference=field(default_factory=DataReference); tick_when_given:int=0
    value_28:int=0; value_40:int=0; delivery_items:list[DeliveryItem]=field(default_factory=list); forced_drops:Optional[ForcedDrops]=None; value_48:int=0; value_52:int=0; value_56:int=0
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer(); w.write_vint(self.value_28); w.write_vint(self.value_40)
        for x in self.delivery_items:x.encode(w)
        w.write_boolean(self.forced_drops is not None)
        if self.forced_drops:self.forced_drops.encode(w)
        w.write_vint(self.value_48); w.write_vint(self.value_52); w.write_vint(self.value_56); w.write_vint(self.tick_when_given)
        w.write_vint(self.base_value_12); w.write_vint(self.base_value_8); wr_ref(w,self.base_global_id); return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload); o=cls(); o.value_28=r.read_vint(); o.value_40=r.read_vint(); o.delivery_items=[DeliveryItem.decode(r) for _ in range(o.value_40)]; o.forced_drops=ForcedDrops.decode(r) if r.read_boolean() else None; o.value_48=r.read_vint(); o.value_52=r.read_vint(); o.value_56=r.read_vint(); o.tick_when_given=r.read_vint(); o.base_value_12=r.read_vint(); o.base_value_8=r.read_vint(); o.base_global_id=rd_ref(r); return o
