class Player {
  constructor ({ id, name = 'Player', data }) {
    this.id = Number(id)
    this.name = name
    this.sessionToken = null
    this.connected = false
    this.client = null
    this.trophies = 0
    this.maxTrophies = 0
    this.gold = 1000
    this.gems = 100
    this.starPoints = 0
    this.tokens = 0
    this.selectedBrawler = 0
    this.brawlers = data ? data.defaultBrawlers() : []
    this.ownedSkins = []
    this.homeState = 'home'
    this.lastSeenAt = Date.now()
  }

  login (client, token) {
    this.client = client
    this.connected = true
    this.sessionToken = token
    this.lastSeenAt = Date.now()
  }

  disconnect () {
    this.connected = false
    this.client = null
    this.lastSeenAt = Date.now()
  }

  selected () {
    return this.brawlers.find((b) => b.id === this.selectedBrawler) || this.brawlers[0] || { id: 0, name: 'Shelly', powerLevel: 1, trophies: 0 }
  }

  selectBrawler (id) {
    if (this.brawlers.some((b) => b.id === Number(id))) this.selectedBrawler = Number(id)
  }

  addTrophies (amount) {
    this.trophies = Math.max(0, this.trophies + Number(amount || 0))
    this.maxTrophies = Math.max(this.maxTrophies, this.trophies)
  }

  snapshot () {
    return {
      id: this.id,
      name: this.name,
      trophies: this.trophies,
      maxTrophies: this.maxTrophies,
      gold: this.gold,
      gems: this.gems,
      starPoints: this.starPoints,
      tokens: this.tokens,
      selectedBrawler: this.selectedBrawler,
      brawlers: this.brawlers,
      ownedSkins: this.ownedSkins,
      state: this.homeState
    }
  }
}

module.exports = Player
