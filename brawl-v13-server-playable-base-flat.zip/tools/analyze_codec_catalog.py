import json
import re
from collections import Counter
from pathlib import Path

root = Path('/home/ubuntu/brawl-v13-server')
data = json.loads((root / 'data/v13/ida_all_v13_codecs.json').read_text())
helper_re = re.compile(r'\b(?:sub_[0-9A-Fa-f]+|ByteStream::[A-Za-z0-9_]+|nullsub_[0-9A-Za-z_]+)\b')
counts = Counter()
empty = []
for packet in data['packets']:
    combined = packet.get('encode_pseudocode', '') + '\n' + packet.get('decode_pseudocode', '')
    helpers = helper_re.findall(combined)
    counts.update(helpers)
    if not combined.strip() or all(x in combined for x in []):
        pass
    if re.search(r'\bnullsub_\d+\s*\(\)\s*\{\s*;?\s*\}', combined) and not re.search(r'\b(?:sub_|ByteStream::)', combined.replace('nullsub_34()', '').replace('nullsub_19()', '')):
        empty.append(packet['name'])
print('packets', len(data['packets']))
print('empty_like', len(empty))
print('empty_names', ','.join(empty[:50]))
print('helpers')
for key, value in counts.most_common():
    print(f'{value:4} {key}')
