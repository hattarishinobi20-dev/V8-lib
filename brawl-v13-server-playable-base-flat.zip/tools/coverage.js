const PacketFactory = require('../protocol/PacketFactory')

const factory = new PacketFactory()
const coverage = factory.coverage()
const failed = coverage.filter((item) => !item.loaded)
console.log(JSON.stringify({
  registryCount: coverage.length,
  loadedCount: coverage.length - failed.length,
  packets: coverage,
  failed
}, null, 2))
if (failed.length) process.exitCode = 1
