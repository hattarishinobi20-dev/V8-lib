const assert = require('assert')
const { EventEmitter } = require('events')
const ClientConnection = require('../network/ClientConnection')
const ServerHelloMessage = require('../messages/Server/ServerHelloMessage')

function fakeSocket () {
  const socket = new EventEmitter()
  socket.remoteAddress = '127.0.0.1'
  socket.destroyed = false
  socket.writes = []
  socket.write = (data) => { socket.writes.push(Buffer.from(data)); return true }
  socket.destroy = () => { socket.destroyed = true }
  return socket
}

function makeFrame (id, version, payload) {
  const header = Buffer.alloc(7)
  header.writeUInt16BE(id, 0)
  header.writeUIntBE(payload.length, 2, 3)
  header.writeUInt16BE(version, 5)
  return Buffer.concat([header, payload, Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0])])
}

async function main () {
  const outboundSocket = fakeSocket()
  const outboundClient = {
    write: (data) => outboundSocket.write(data),
    log: () => {}
  }
  const hello = new ServerHelloMessage(outboundClient)
  hello.send()
  assert.strictEqual(outboundSocket.writes.length, 1)
  const wire = outboundSocket.writes[0]
  const payloadLength = wire.readUIntBE(2, 3)
  assert.strictEqual(wire.readUInt16BE(0), 20100)
  assert.strictEqual(wire.readUInt16BE(5), 0)
  assert.strictEqual(payloadLength, wire.length - 14)
  assert.deepStrictEqual(wire.slice(7 + payloadLength), Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0]))

  const inboundSocket = fakeSocket()
  const received = []
  const server = {
    receivePacket: (...args) => received.push(args),
    players: { detach: () => {} },
    clients: new Set(),
    log: { warn: () => {}, info: () => {}, debug: () => {} }
  }
  const connection = new ClientConnection(server, inboundSocket)
  const first = makeFrame(10100, 7, Buffer.from([0x01, 0x02]))
  const second = makeFrame(10101, 8, Buffer.from([0x03]))
  const wireIn = Buffer.concat([first, second])
  connection.receive(wireIn.slice(0, 5))
  assert.strictEqual(received.length, 0)
  connection.receive(wireIn.slice(5, 16))
  assert.strictEqual(received.length, 1)
  connection.receive(wireIn.slice(16))
  assert.strictEqual(received.length, 2)
  assert.deepStrictEqual(received[0].slice(0, 3), [connection, 10100, 7])
  assert.deepStrictEqual(received[0][3], Buffer.from([0x01, 0x02]))
  assert.deepStrictEqual(received[1].slice(0, 3), [connection, 10101, 8])
  assert.deepStrictEqual(received[1][3], Buffer.from([0x03]))

  console.log('framing-test: ok')
}

main().catch((error) => {
  console.error(error.stack || error.message)
  process.exitCode = 1
})
