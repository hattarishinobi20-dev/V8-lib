const assert = require('assert')
const LoginOkMessage = require('../messages/Server/LoginOkMessage')
const KeepAliveServerMessage = require('../messages/Server/KeepAliveServerMessage')
const OwnHomeDataMessage = require('../messages/Server/OwnHomeDataMessage')
const ServerHelloMessage = require('../messages/Server/ServerHelloMessage')
const GoHomeMessage = require('../messages/Client/GoHomeMessage')
const ClientHomeMessage = require('../messages/Client/ClientHomeMessage')
const V13ByteStream = require('../protocol/V13ByteStream')

const TRAILER = Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0])

function makeClient () {
  const client = {
    writes: [],
    logs: [],
    player: {
      id: 123,
      name: 'Tester',
      sessionToken: 'session-token',
      trophies: 42,
      maxTrophies: 50,
      gold: 1000,
      gems: 100,
      starPoints: 7,
      tokens: 3,
      selectedBrawler: 0,
      brawlers: [{ id: 0, name: 'Shelly', powerLevel: 1, trophies: 0 }],
      selected () { return this.brawlers[0] }
    },
    server: { context: { version: 'v13' } },
    write (bytes) { this.writes.push(Buffer.from(bytes)); return true },
    log (line) { this.logs.push(line) }
  }
  return client
}

function decodeFrame (frame) {
  assert.strictEqual(frame.length >= 14, true)
  const id = frame.readUInt16BE(0)
  const length = frame.readUIntBE(2, 3)
  const version = frame.readUInt16BE(5)
  assert.strictEqual(frame.length, 7 + length + 7)
  assert.deepStrictEqual(frame.slice(7 + length), TRAILER)
  return { id, length, version, payload: frame.slice(7, 7 + length) }
}

function testPriorityPackets () {
  const client = makeClient()

  new ServerHelloMessage(client, client.server.context).send()
  let frame = decodeFrame(client.writes.pop())
  assert.strictEqual(frame.id, 20100)
  assert.strictEqual(frame.version, 0)
  assert.strictEqual(frame.length, 28)
  assert.strictEqual(frame.payload.readInt32BE(0), 24)
  assert.deepStrictEqual(frame.payload.slice(4), Buffer.alloc(24, 1))

  new KeepAliveServerMessage(client, client.server.context).send()
  frame = decodeFrame(client.writes.pop())
  assert.strictEqual(frame.id, 20108)
  assert.strictEqual(frame.length, 0)

  new LoginOkMessage(client, client.server.context).send()
  frame = decodeFrame(client.writes.pop())
  assert.strictEqual(frame.id, 20104)
  const login = new V13ByteStream(frame.payload)
  assert.deepStrictEqual(login.readLogicLong(), [0, 123])
  assert.deepStrictEqual(login.readLogicLong(), [0, 123])
  assert.strictEqual(login.readString(), 'session-token')
  assert.strictEqual(login.readString(), '')
  assert.strictEqual(login.readString(), '')
  assert.strictEqual(login.readVInt(), 13)
  assert.strictEqual(login.readVInt(), 0)
  assert.strictEqual(login.readVInt(), 0)
  assert.strictEqual(login.readString(), 'dev')

  new OwnHomeDataMessage(client, client.server.context).send()
  frame = decodeFrame(client.writes.pop())
  assert.strictEqual(frame.id, 24101)
  assert.ok(frame.length > 100)
  assert.strictEqual(frame.payload[frame.payload.length - 1], 0)

  assert.strictEqual(ClientHomeMessage, GoHomeMessage)
  assert.strictEqual(new ClientHomeMessage(null, client, client.server.context).id, 14101)
  return true
}

testPriorityPackets()
console.log('priority packet tests: ok')
