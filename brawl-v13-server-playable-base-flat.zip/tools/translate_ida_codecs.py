import concurrent.futures
import json
import os
import re
import sys
import time
from pathlib import Path

from openai import OpenAI

ROOT = Path('/home/ubuntu/brawl-v13-server')
SOURCE = ROOT / 'data/v13/ida_all_v13_codecs.json'
OUTPUT = ROOT / 'data/v13/translated_codecs.json'
MODEL = os.environ.get('IDA_TRANSLATION_MODEL', 'gpt-5-mini')
MAX_WORKERS = int(os.environ.get('IDA_TRANSLATION_WORKERS', '6'))

SCHEMA = {
    'type': 'object',
    'properties': {
        'encode': {'type': 'string'},
        'decode': {'type': 'string'},
        'notes': {'type': 'string'},
    },
    'required': ['encode', 'decode', 'notes'],
    'additionalProperties': False,
}

SYSTEM = r'''
You translate Brawl Stars v13 ARM32 IDA pseudocode into precise JavaScript method bodies.
Return only JSON matching the supplied schema. The output fields are the bodies of encode() and decode().
The generated class extends V13Message, which inherits PiranhaMessage and the nodebrawl-core ByteStream.
Available writer methods: writeVInt, writeInt, writeBoolean, writeString, writeDataReference, writeByte,
writeShort, writeLong, writeLogicLong, writeBytes. Available reader methods: readVInt, readInt,
readBoolean, readString, readDataReference, readByte (if present), readShort, readLong, readLogicLong.
Use `this.fields` as a JSON-friendly array for decoded values and as optional input values for encoding.
Start decode bodies with `this.fields = []` and append each wire-level value in exact order.
Start encode bodies with `const f = this.fields || []` and consume values in exact order, defaulting missing numeric
values to 0, booleans to false, strings to '', references to [0,0], and lists to [].
For a primitive write/read call in pseudocode, use the matching ByteStream method. `sub_DD380` and `sub_5006AC`
are VInt; `sub_304138`/`sub_699D34` are strings; `sub_4EB390`/`sub_21D53C` are booleans;
`sub_447E3C`/`sub_FCC04` are data references; `sub_FBD88` is a logic long; ByteStream::readIntInternal is readInt.
For a loop over a collection, encode a VInt count then each item, and decode count then that many items.
For optional branches, preserve the condition by checking the decoded/encoded field value; do not invent a branch.
For unknown helper calls whose nested wire layout is unavailable, use `this.readOpaqueCall('helper')` or
`this.writeOpaqueCall('helper', value)`, and record the helper in notes. These runtime methods preserve bytes and
are preferable to silently dropping fields. Do not use decodeOpaque() or return this.buffer without writing.
Do not import modules, define classes, use markdown fences, or mention later protocol versions.
'''


def extract_json(text):
    text = text.strip()
    if text.startswith('```'):
        text = re.sub(r'^```(?:json)?\s*', '', text)
        text = re.sub(r'\s*```$', '', text)
    return json.loads(text)


def translate(packet):
    client = OpenAI(timeout=45.0, max_retries=0)
    prompt = (
        f"Packet {packet['name']} (ID {packet['id']}) from v13 libv13.so.\n"
        f"IDA encode pseudocode:\n{packet.get('encode_pseudocode', '')}\n\n"
        f"IDA decode pseudocode:\n{packet.get('decode_pseudocode', '')}\n"
    )
    last = None
    for attempt in range(3):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=[{'role': 'system', 'content': SYSTEM}, {'role': 'user', 'content': prompt}],
                response_format={
                    'type': 'json_schema',
                    'json_schema': {'name': 'ida_codec_translation', 'strict': True, 'schema': SCHEMA},
                },
                max_completion_tokens=4000,
                extra_body={'reasoning': {'effort': 'minimal'}},
            )
            content = response.choices[0].message.content
            result = extract_json(content)
            result['id'] = packet['id']
            result['name'] = packet['name']
            result['encode_address'] = packet.get('encode')
            result['decode_address'] = packet.get('decode')
            return result
        except Exception as exc:
            last = exc
            time.sleep(2 ** attempt)
    raise RuntimeError(f"{packet['name']} failed: {last}")


def main():
    packets = json.loads(SOURCE.read_text())['packets']
    existing = {}
    if OUTPUT.exists():
        try:
            existing = {item['id']: item for item in json.loads(OUTPUT.read_text())}
        except Exception:
            existing = {}
    todo = [packet for packet in packets if packet['id'] not in existing]
    print(f'model={MODEL} total={len(packets)} cached={len(existing)} todo={len(todo)} workers={MAX_WORKERS}', flush=True)
    results = dict(existing)
    failures = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        futures = {executor.submit(translate, packet): packet for packet in todo}
        for index, future in enumerate(concurrent.futures.as_completed(futures), 1):
            packet = futures[future]
            try:
                item = future.result()
                results[item['id']] = item
                print(f'[{index}/{len(todo)}] {packet["id"]} {packet["name"]}', flush=True)
            except Exception as exc:
                failures.append({'id': packet['id'], 'name': packet['name'], 'error': str(exc)})
                print(f'FAILED {packet["id"]} {packet["name"]}: {exc}', file=sys.stderr, flush=True)
            if index % 10 == 0:
                OUTPUT.write_text(json.dumps(sorted(results.values(), key=lambda x: x['id']), ensure_ascii=False, indent=2))
    OUTPUT.write_text(json.dumps(sorted(results.values(), key=lambda x: x['id']), ensure_ascii=False, indent=2))
    if failures:
        (ROOT / 'data/v13/translation_failures.json').write_text(json.dumps(failures, ensure_ascii=False, indent=2))
        raise SystemExit(f'{len(failures)} translations failed')
    print(f'wrote {len(results)} translations to {OUTPUT}')


if __name__ == '__main__':
    main()
