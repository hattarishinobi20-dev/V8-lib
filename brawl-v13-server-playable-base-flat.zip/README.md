# Servidor Brawl Stars v13 — base jogável sobre nodebrawl-core

Este projeto contém uma base jogável de testes para o protocolo Brawl Stars v13. A implementação usa o `nodebrawl-core` como camada obrigatória de transporte, `PiranhaMessage` e `ByteStream`, adicionando apenas a extensão v13 necessária para corrigir as leituras de VInt e de booleanos bit-packed. O servidor mantém jogadores, brawlers, recursos e sessões em SQLite por meio de `node:sqlite` do Node.js 22.

> **Escopo atual:** a runtime foi deliberadamente reduzida para o fluxo inicial funcional. Os codecs de saída prioritários são `ServerHelloMessage` (20100), `LoginOkMessage` (20104), `KeepAliveServerMessage` (20108) e `OwnHomeDataMessage` (24101), além de `ClientHomeMessage`/`GoHomeMessage` (14101). `ClientHelloMessage` (10100) e `TitanLoginMessage` (10101) permanecem apenas como entradas indispensáveis para iniciar o handshake e o login. Nenhum wrapper genérico dos demais pacotes é carregado ou distribuído na pasta `messages/`.

## Requisitos e instalação

É necessário utilizar Node.js 22.5 ou superior, porque o banco usa a API experimental `node:sqlite` disponibilizada nessa linha do Node.js. Não há dependências npm externas no projeto.

```bash
cd /home/ubuntu/brawl-v13-server
npm install
npm test
npm start
```

O servidor escuta por padrão em `0.0.0.0:9339`. É possível alterar a configuração com `HOST` e `PORT`:

```bash
HOST=127.0.0.1 PORT=9339 npm start
```

O arquivo SQLite padrão fica em `data/server.sqlite3`; o caminho pode ser alterado pela API de instanciação de `V13Server` usando `databaseFile`.

## Fluxo prioritário validado

O cliente inicia enviando um frame v13 de `ClientHelloMessage` (10100). O servidor responde com `ServerHelloMessage` (20100), inicia o temporizador de keepalive e aceita `TitanLoginMessage` (10101). O login cria ou recupera o jogador, gera uma sessão persistida, envia `LoginOkMessage` (20104) e em seguida `OwnHomeDataMessage` (24101). O pacote de retorno à home é identificado no inventário v13 como `GoHomeMessage` (14101); `ClientHomeMessage.js` é um alias explícito para esse mesmo pacote, sem duplicar o registro do ID.

O framing é validado com header de 7 bytes — ID u16, tamanho u24 e versão u16 —, payload e trailer de 7 bytes `ff ff 00 00 00 00 00`. O parser aceita fragmentação TCP em qualquer fronteira e rejeita trailers inválidos.

## Persistência

A base cria as tabelas `players`, `player_brawlers`, `player_skins` e `sessions`. O fluxo de login salva a identidade do jogador, nome, troféus, maior número de troféus, ouro, gemas, star points, tokens, brawler selecionado, estado da home, brawlers padrão e token de sessão. O teste TCP fecha o servidor, reabre o SQLite e recupera o jogador por seu token para provar a persistência.

## Testes

O comando oficial combina quatro verificações:

```bash
npm test
```

| Teste | Cobertura |
|---|---|
| `tools/smoke-test.js` | VInt v13, referências, booleanos, strings, SQLite e inicialização básica |
| `tools/framing-test.js` | Header/trailer, tamanho do payload, fragmentação e rejeição do trailer inválido |
| `tools/priority-packets-test.js` | IDs e payloads de ServerHello, KeepAlive, LoginOk, OwnHomeData e ClientHome |
| `tools/tcp-playable-test.js` | Conexão TCP real, handshake, login, home, frames fragmentados e restauração da sessão |

A auditoria da registry mínima pode ser executada com:

```bash
npm run check
```

## Organização principal

| Diretório | Responsabilidade |
|---|---|
| `server/` | Entrypoint e composição do servidor v13 |
| `network/` | Conexão TCP, framing e keepalive |
| `protocol/` | Extensão v13 sobre `PiranhaMessage` e `ByteStream` do core |
| `messages/` | Pacotes de cliente e servidor |
| `handlers/` | Roteamento e processamento dos pacotes |
| `players/` | Modelo, sessões e ciclo de vida do jogador |
| `database/` | SQLite e carregamento dos CSVs v13 |
| `rooms/` e `battle/` | Estruturas iniciais de equipes e batalhas |
| `data/v13/` | Referências IDA, pseudocódigos e CSVs v13, sem carregamento automático de wrappers |
| `tools/` | Testes e auditorias automatizadas |

A fonte de verdade dos layouts específicos v13 permanece em `data/v13/ida_all_v13_codecs.json` e na referência local `own_home_data_message_v13.py`. As referências públicas auxiliares usadas para primitivas de protocolo estão registradas em `data/v13/external_protocol_refs.md`.
