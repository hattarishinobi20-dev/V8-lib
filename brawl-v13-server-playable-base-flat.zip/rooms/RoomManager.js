const crypto = require('crypto')

class RoomManager {
  constructor (server) {
    this.server = server
    this.rooms = new Map()
    this.byPlayer = new Map()
  }

  create (owner) {
    const id = crypto.randomBytes(4).toString('hex')
    const room = { id, owner, players: [owner], state: 'waiting', createdAt: Date.now() }
    this.rooms.set(id, room)
    this.byPlayer.set(owner.id, room)
    owner.homeState = 'room'
    return room
  }

  join (roomId, player) {
    const room = this.rooms.get(String(roomId))
    if (!room || room.state !== 'waiting' || room.players.length >= 3) return null
    if (!room.players.some((item) => item.id === player.id)) room.players.push(player)
    this.byPlayer.set(player.id, room)
    player.homeState = 'room'
    return room
  }

  leave (player) {
    const room = this.byPlayer.get(player.id)
    if (!room) return null
    room.players = room.players.filter((item) => item.id !== player.id)
    this.byPlayer.delete(player.id)
    player.homeState = 'home'
    if (!room.players.length) this.rooms.delete(room.id)
    else if (room.owner.id === player.id) room.owner = room.players[0]
    return room
  }

  getFor (player) { return this.byPlayer.get(player.id) || null }
}

module.exports = RoomManager
