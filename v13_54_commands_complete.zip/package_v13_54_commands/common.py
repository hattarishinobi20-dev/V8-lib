from __future__ import annotations

from dataclasses import dataclass
import struct
from typing import Optional, Sequence


class Writer:
    """ByteStream v13 traduzido das primitivas usadas pelos helpers do IDA."""

    def __init__(self) -> None:
        self.buf = bytearray()
        self.bit_offset = 0

    def _reset_bits(self) -> None:
        self.bit_offset = 0

    def _append(self, data: bytes) -> None:
        self._reset_bits()
        self.buf.extend(data)

    def write_vint(self, value: int) -> None:
        value = int(value)
        if value > 0x7FFFFFFF:
            value -= 0x100000000
        if not -0x80000000 <= value <= 0x7FFFFFFF:
            raise ValueError(f"VInt fora de 32 bits: {value}")
        negative = value < 0
        if negative:
            if value >= -63:
                out = [(value & 0x3F) | 0x40]
            elif value >= -8191:
                out = [(value & 0x3F) | 0xC0, (value >> 6) & 0x7F]
            elif value >= -1048575:
                out = [(value & 0x3F) | 0xC0, ((value >> 6) & 0x7F) | 0x80, (value >> 13) & 0x7F]
            elif value >= -134217727:
                out = [(value & 0x3F) | 0xC0, ((value >> 6) & 0x7F) | 0x80, ((value >> 13) & 0x7F) | 0x80, (value >> 20) & 0x7F]
            else:
                out = [(value & 0x3F) | 0xC0, ((value >> 6) & 0x7F) | 0x80, ((value >> 13) & 0x7F) | 0x80, ((value >> 20) & 0x7F) | 0x80, (value >> 27) & 0x0F]
        elif value <= 63:
            out = [value & 0x3F]
        elif value <= 8191:
            out = [(value & 0x3F) | 0x80, (value >> 6) & 0x7F]
        elif value <= 1048575:
            out = [(value & 0x3F) | 0x80, ((value >> 6) & 0x7F) | 0x80, (value >> 13) & 0x7F]
        elif value <= 134217727:
            out = [(value & 0x3F) | 0x80, ((value >> 6) & 0x7F) | 0x80, ((value >> 13) & 0x7F) | 0x80, (value >> 20) & 0x7F]
        else:
            out = [(value & 0x3F) | 0x80, ((value >> 6) & 0x7F) | 0x80, ((value >> 13) & 0x7F) | 0x80, ((value >> 20) & 0x7F) | 0x80, (value >> 27) & 0x0F]
        self._append(bytes(out))

    def write_vlong(self, high: int = 0, low: int = 0) -> None:
        self.write_vint(high)
        self.write_vint(low)

    def write_boolean(self, value: bool) -> None:
        if self.bit_offset == 0:
            self.buf.append(0)
        if value:
            self.buf[-1] |= 1 << self.bit_offset
        self.bit_offset = (self.bit_offset + 1) & 7

    write_bool = write_boolean

    def write_int(self, value: int) -> None:
        self._append(struct.pack(">i", int(value)))

    def write_uint(self, value: int) -> None:
        self._append(struct.pack(">I", int(value) & 0xFFFFFFFF))

    def write_byte(self, value: int) -> None:
        self._append(bytes([int(value) & 0xFF]))

    def write_short(self, value: int) -> None:
        self._append(struct.pack(">H", int(value) & 0xFFFF))

    def write_long(self, value: int) -> None:
        self._append(struct.pack(">q", int(value)))

    def write_string(self, value: Optional[str]) -> None:
        if value is None:
            self.write_int(-1)
            return
        raw = str(value).encode("utf-8")
        self.write_int(len(raw))
        self.buf.extend(raw)
        self._reset_bits()

    def write_data_reference(self, high: int = 0, low: int = -1) -> None:
        self.write_vint(high)
        if int(high) != 0:
            self.write_vint(low)

    def write_bytes(self, value: bytes | bytearray | None) -> None:
        if value is None:
            self.write_int(-1)
            return
        raw = bytes(value)
        self.write_int(len(raw))
        self.buf.extend(raw)
        self._reset_bits()

    def write_int_list(self, values: Sequence[int]) -> None:
        self.write_vint(len(values))
        for value in values:
            self.write_vint(value)

    def bytes(self) -> bytes:
        return bytes(self.buf)


class Reader:
    """Leitor inverso das primitivas ByteStream usadas pelos decoders do IDA."""

    def __init__(self, data: bytes = b"") -> None:
        self.data = memoryview(data)
        self.offset = 0
        self.bit_offset = 0
        self._boolean_byte = 0

    def _reset_bits(self) -> None:
        self.bit_offset = 0

    def _take(self, size: int) -> bytes:
        self._reset_bits()
        end = self.offset + size
        if end > len(self.data):
            raise EOFError("payload truncado")
        chunk = self.data[self.offset:end].tobytes()
        self.offset = end
        return chunk

    def read_vint(self) -> int:
        self._reset_bits()
        first = self._take(1)[0]
        result = first & 0x3F
        shift = 6
        if first & 0x80:
            while True:
                byte = self._take(1)[0]
                result |= (byte & 0x7F) << shift
                shift += 7
                if not (byte & 0x80) or shift >= 35:
                    break
        if first & 0x40 and shift < 32:
            result |= -1 << shift
        return result

    def read_vlong(self) -> tuple[int, int]:
        return self.read_vint(), self.read_vint()

    def read_boolean(self) -> bool:
        if self.bit_offset == 0:
            self._boolean_byte = self._take(1)[0]
        value = bool(self._boolean_byte & (1 << self.bit_offset))
        self.bit_offset = (self.bit_offset + 1) & 7
        return value

    read_bool = read_boolean

    def read_int(self) -> int:
        return struct.unpack(">i", self._take(4))[0]

    def read_uint(self) -> int:
        return struct.unpack(">I", self._take(4))[0]

    def read_byte(self) -> int:
        return self._take(1)[0]

    def read_short(self) -> int:
        return struct.unpack(">H", self._take(2))[0]

    def read_long(self) -> int:
        return struct.unpack(">q", self._take(8))[0]

    def read_string(self) -> Optional[str]:
        length = self.read_int()
        if length < 0:
            return None
        return self._take(length).decode("utf-8")

    def read_data_reference(self) -> tuple[int, int]:
        high = self.read_vint()
        return (high, self.read_vint()) if high else (0, -1)

    def read_bytes(self) -> bytes | None:
        length = self.read_int()
        if length < 0:
            return None
        return self._take(length)

    def read_int_list(self) -> list[int]:
        return [self.read_vint() for _ in range(self.read_vint())]


@dataclass
class DataReference:
    high: int = 0
    low: int = -1


class Packet:
    """Contrato individual comum; cada arquivo de pacote fornece seus campos e codecs."""

    id: int = 0
    service_node_type: int = 0

    def encode(self) -> bytes:
        raise NotImplementedError

    @classmethod
    def decode(cls, payload: bytes):
        raise NotImplementedError
