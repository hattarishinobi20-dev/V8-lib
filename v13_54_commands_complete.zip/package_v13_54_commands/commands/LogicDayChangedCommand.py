from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high,x.low)
def rd_vint_list(r: Reader) -> list[int]:
    return [r.read_vint() for _ in range(r.read_vint())]
def wr_vint_list(w: Writer, xs: list[int]) -> None:
    w.write_vint(len(xs))
    for x in xs:w.write_vint(x)

@dataclass
class EventSlot:
    value:int=0
    def encode(self,w:Writer)->None:w.write_vint(self.value)
    @classmethod
    def decode(cls,r:Reader):return cls(r.read_vint())

@dataclass
class ChronosEntry:
    values:list[int]=field(default_factory=lambda:[0]*5)
    global_id:DataReference=field(default_factory=DataReference)
    value_24:int=0; text:str|None=None; values_tail:list[int]=field(default_factory=lambda:[0]*3); list_values:list[int]=field(default_factory=list); value_48:int=0; value_52:int=0
    def encode(self,w:Writer)->None:
        for x in self.values:w.write_vint(x)
        wr_ref(w,self.global_id);w.write_vint(self.value_24);w.write_string(self.text)
        for x in self.values_tail:w.write_vint(x)
        wr_vint_list(w,self.list_values);w.write_vint(self.value_48);w.write_vint(self.value_52)
    @classmethod
    def decode(cls,r:Reader):
        return cls([r.read_vint() for _ in range(5)],rd_ref(r),r.read_vint(),r.read_string(),[r.read_vint() for _ in range(3)],rd_vint_list(r),r.read_vint(),r.read_vint())

@dataclass
class RefIntPair:
    global_id:DataReference=field(default_factory=DataReference); value_4:int=0; value_8:int=0
    def encode(self,w:Writer)->None:wr_ref(w,self.global_id);w.write_int(self.value_4);w.write_int(self.value_8)
    @classmethod
    def decode(cls,r:Reader):return cls(rd_ref(r),r.read_int(),r.read_int())

@dataclass
class Vector2Entry:
    x:int=0;y:int=0
    def encode(self,w:Writer)->None:w.write_vint(self.x);w.write_vint(self.y)
    @classmethod
    def decode(cls,r:Reader):return cls(r.read_vint(),r.read_vint())

@dataclass
class TimedIntEntry:
    values:list[int]=field(default_factory=lambda:[0]*4)
    def encode(self,w:Writer):
        for x in self.values:w.write_vint(x)
    @classmethod
    def decode(cls,r:Reader):return cls([r.read_vint() for _ in range(4)])

@dataclass
class DayState:
    values:list[int]=field(default_factory=lambda:[0]*12)
    int_lists:list[list[int]]=field(default_factory=lambda:[[] for _ in range(7)])
    event_slots:list[EventSlot]=field(default_factory=list)
    chronos_entries:list[ChronosEntry]=field(default_factory=list)
    ref_int_pairs:list[RefIntPair]=field(default_factory=list)
    tail_lists:list[list[int]]=field(default_factory=lambda:[[] for _ in range(6)])
    tail_values:list[int]=field(default_factory=lambda:[0]*6)
    flags:list[bool]=field(default_factory=lambda:[False]*4)
    final_ints:list[int]=field(default_factory=list)
    vectors:list[Vector2Entry]=field(default_factory=list)
    timed_entries:list[TimedIntEntry]=field(default_factory=list)
    def encode(self,w:Writer)->None:
        for x in self.values:w.write_vint(x)
        for xs in self.int_lists:wr_vint_list(w,xs)
        wr_vint_list(w,[x.value for x in self.event_slots])
        w.write_vint(len(self.chronos_entries))
        for x in self.chronos_entries:x.encode(w)
        w.write_vint(len(self.ref_int_pairs))
        for x in self.ref_int_pairs:x.encode(w)
        for xs in self.tail_lists:wr_vint_list(w,xs)
        for x in self.tail_values:w.write_vint(x)
        for x in self.flags:w.write_boolean(x)
        wr_vint_list(w,self.final_ints)
        w.write_vint(len(self.vectors))
        for x in self.vectors:x.encode(w)
        w.write_vint(len(self.timed_entries))
        for x in self.timed_entries:x.encode(w)
    @classmethod
    def decode(cls,r:Reader):
        o=cls();o.values=[r.read_vint() for _ in range(12)];o.int_lists=[rd_vint_list(r) for _ in range(7)];o.event_slots=[EventSlot(x) for x in rd_vint_list(r)];o.chronos_entries=[ChronosEntry.decode(r) for _ in range(r.read_vint())];o.ref_int_pairs=[RefIntPair.decode(r) for _ in range(r.read_vint())];o.tail_lists=[rd_vint_list(r) for _ in range(6)];o.tail_values=[r.read_vint() for _ in range(6)];o.flags=[r.read_boolean() for _ in range(4)];o.final_ints=rd_vint_list(r);o.vectors=[Vector2Entry.decode(r) for _ in range(r.read_vint())];o.timed_entries=[TimedIntEntry.decode(r) for _ in range(r.read_vint())];return o

@dataclass
class LogicDayChangedCommand:
    id:int=204;base_value_8:int=0;base_value_12:int=0;base_global_id:DataReference=field(default_factory=DataReference);tick_when_given:int=0;day_state:Optional[DayState]=None
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_boolean(self.day_state is not None)
        if self.day_state:self.day_state.encode(w)
        w.write_vint(self.tick_when_given);w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls();o.day_state=DayState.decode(r) if r.read_boolean() else None;o.tick_when_given=r.read_vint();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);return o
