const V13Message = require('../../protocol/V13Message')

class ServerHelloMessage extends V13Message {
  constructor (client = null, context = null) {
    super(null, client, context)
    this.id = 20100
    this.version = 0
  }

  encode () {
    this.writeInt(24)
    for (let i = 0; i < 24; i += 1) this.writeByte(1)
    return this.buffer
  }
}

module.exports = ServerHelloMessage
