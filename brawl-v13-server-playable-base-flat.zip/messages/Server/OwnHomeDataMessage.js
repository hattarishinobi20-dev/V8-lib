const V13Message = require('../../protocol/V13Message')

function writeFixedVInts (stream, values, count) {
  const list = Array.isArray(values) ? values.slice(0, count) : []
  while (list.length < count) list.push(0)
  for (const value of list) stream.writeVInt(Number(value) || 0)
}

function writeVIntList (stream, values) {
  const list = Array.isArray(values) ? values : []
  stream.writeVInt(list.length)
  for (const value of list) stream.writeVInt(Number(value) || 0)
}

function writeDataReference (stream, high = 0, low = -1) {
  stream.writeDataReference(Number(high) || 0, Number(low) || 0)
}

function writeDataReferenceList (stream, values) {
  const list = Array.isArray(values) ? values : []
  stream.writeVInt(list.length)
  for (const item of list) {
    if (Array.isArray(item)) writeDataReference(stream, item[0], item[1])
    else if (item && typeof item === 'object') writeDataReference(stream, item.high, item.low)
    else writeDataReference(stream)
  }
}

function writePairInt (stream, pair) {
  const item = pair || {}
  writeDataReference(stream, item.high, item.low)
  stream.writeInt(Number(item.first) || 0)
  stream.writeInt(Number(item.second) || 0)
}

function writeForcedDrops (stream) {
  stream.writeVInt(0)
  stream.writeVInt(0)
  writeVIntList(stream, [])
}

function writeChronosTextEntry (stream, entry = {}) {
  stream.writeInt(Number(entry.timestamp) || 0)
  stream.writeString(entry.text == null ? '' : String(entry.text))
}

function writeEventRecord (stream, record = {}) {
  writeVIntList(stream, record.nestedValues || [])
  stream.writeVInt(Number(record.v16) || 0)
  stream.writeVInt(Number(record.v12) || 0)
  stream.writeVInt(Number(record.v20) || 0)
  stream.writeVInt(Number(record.v24) || 0)
  stream.writeVInt(Number(record.v28) || 0)
  stream.writeBoolean(Boolean(record.flag32))
  stream.writeVInt(Number(record.v36) || 0)
  stream.writeBoolean(Boolean(record.flag44))
  stream.writeVInt(Number(record.v56) || 0)
  writeChronosTextEntry(stream, record.chronos)
  stream.writeBoolean(Boolean(record.flag64))
  stream.writeString(record.stringRef == null ? '' : String(record.stringRef))
  stream.writeVInt(Number(record.v60) || 0)
  stream.writeBoolean(Boolean(record.flag65))
}

function writeHomeEntry (stream, entry = {}) {
  stream.writeVInt(Number(entry.v0) || 0)
  writeDataReference(stream, entry.ref0High, entry.ref0Low)
  stream.writeVInt(Number(entry.v1) || 0)
  writeDataReference(stream, entry.ref1High, entry.ref1Low)
  writeDataReference(stream, entry.ref2High, entry.ref2Low)
  writeDataReference(stream, entry.ref3High, entry.ref3Low)
  stream.writeVInt(Number(entry.v2) || 0)
}

function writeHomeData (stream, player) {
  // sub_2CA6A4: seven VInts, two references and the home collections.
  writeFixedVInts(stream, [
    0,
    0,
    player.trophies,
    player.maxTrophies,
    0,
    player.gems,
    player.gold
  ], 7)
  writeDataReference(stream)
  writeDataReference(stream)
  writeVIntList(stream, [])
  writeDataReferenceList(stream, [])
  writeDataReferenceList(stream, [])
  writeDataReferenceList(stream, [])
  writeFixedVInts(stream, [], 4)
  stream.writeBoolean(false)
  writeFixedVInts(stream, [], 4)
  writeForcedDrops(stream)

  // Optional PairInt fields are presence-bit booleans in the native codec.
  stream.writeBoolean(false)
  stream.writeBoolean(false)
  stream.writeBoolean(false)

  writeFixedVInts(stream, [], 5)
  const events = []
  stream.writeVInt(events.length)
  for (const record of events) writeEventRecord(stream, record)
  const adStatuses = []
  stream.writeVInt(adStatuses.length)
  for (const status of adStatuses) {
    stream.writeVInt(Number(status.a) || 0)
    stream.writeVInt(Number(status.b) || 0)
    stream.writeVInt(Number(status.c) || 0)
  }
  writeFixedVInts(stream, [], 2)
  writeVIntList(stream, [])
  writeFixedVInts(stream, [], 2)
  writeDataReference(stream)
  stream.writeString('')
  stream.writeString('')

  // sub_362BE0/sub_10CF28 optional collections: null pointers become false.
  writeVIntList(stream, [])
  writeVIntList(stream, [])
  writeVIntList(stream, [])
  writeVIntList(stream, [])
  stream.writeBoolean(false)
  stream.writeBoolean(false)
}

function writeAvatarRecord (stream, record = {}) {
  writeFixedVInts(stream, record.values0to4, 5)
  writeDataReference(stream, record.refHigh, record.refLow)
  stream.writeVInt(Number(record.v6) || 0)
  stream.writeString(record.string7 == null ? '' : String(record.string7))
  writeFixedVInts(stream, record.values8to10, 3)
  writeVIntList(stream, record.listValues || [])
  stream.writeVInt(Number(record.v12) || 0)
  stream.writeVInt(Number(record.v13) || 0)
}

function writeClientAvatar (stream, player) {
  const selected = typeof player.selected === 'function' ? player.selected() : {}
  writeFixedVInts(stream, [
    Number(player.selectedBrawler) || 0,
    Number(selected.id) || 0,
    Number(selected.powerLevel) || 1,
    Number(selected.trophies) || 0
  ], 12)
  writeVIntList(stream, [])
  writeVIntList(stream, [])
  stream.writeVInt(0)
  stream.writeVInt(0)
  for (let i = 0; i < 6; i += 1) writeVIntList(stream, [])
  writeFixedVInts(stream, [], 6)
  stream.writeBoolean(false)
  stream.writeBoolean(false)
  stream.writeBoolean(false)
  writeFixedVInts(stream, [], 2)
  stream.writeBoolean(false)
  writeVIntList(stream, [])
  writeVIntList(stream, [])
  writeVIntList(stream, [])
}

function writeLogicClientHome (stream, player) {
  writeHomeData(stream, player)
  writeClientAvatar(stream, player)

  // LogicVector2.
  stream.writeInt(0)
  stream.writeInt(0)
  stream.writeVInt(0)

  const homeEntries = []
  stream.writeVInt(homeEntries.length)
  for (const entry of homeEntries) writeHomeEntry(stream, entry)
  stream.writeVInt(0)
  stream.writeBoolean(false)

  // The native null collection branch writes a zero count, not a presence bit.
  stream.writeVInt(0)
  writeDataReferenceList(stream, [])
}

function writeAvatarTriple (stream, item = {}) {
  writeDataReference(stream, item.high, item.low)
  stream.writeVInt(Number(item.value) || 0)
}

function writeAvatarStreamData (stream) {
  // Three PairVInt records.
  for (let i = 0; i < 3; i += 1) {
    stream.writeVInt(0)
    stream.writeVInt(0)
  }
  stream.writeString('')
  stream.writeBoolean(false)
  stream.writeInt(0)

  // Eight commodity lists, followed by twelve tail VInts.
  stream.writeVInt(8)
  for (let i = 0; i < 8; i += 1) writeVIntList(stream, [])
  writeFixedVInts(stream, [], 12)
}

class OwnHomeDataMessage extends V13Message {
  constructor (client = null, context = null) {
    super(null, client, context)
    this.id = 24101
    this.version = 0
  }

  encode () {
    const player = (this.client && this.client.player) || {
      trophies: 0,
      maxTrophies: 0,
      gems: 0,
      gold: 0,
      selectedBrawler: 0,
      selected: () => ({ id: 0, powerLevel: 1, trophies: 0 })
    }
    writeLogicClientHome(this, player)
    writeAvatarStreamData(this)
    this.writeVInt(0)
    return this.buffer
  }
}

module.exports = OwnHomeDataMessage
module.exports.writeLogicClientHome = writeLogicClientHome
module.exports.writeAvatarStreamData = writeAvatarStreamData
