# Commands v13

Este diretório contém as 54 classes de commands do contrato extraído de `libv13.so.i64`, cada uma em um arquivo Python próprio. Os IDs são registrados individualmente em `v13_command_registry.py`.

## Uso

A partir do diretório pai de `commands`, importe:

```python
from commands.v13_command_registry import get_command_class

command_cls = get_command_class(201)
command = command_cls()
payload = command.encode()
decoded = command_cls.decode(payload)
```

A classe `Reader`/`Writer` usada pelos codecs está em `../common.py`. O registro contém os 54 IDs do contrato `v13_commands_compatibility_contract.json`.

## Validação

A auditoria `audit_final_54_commands.py` importa as 54 classes, confirma IDs únicos, procura marcadores explícitos de placeholder e executa round-trip com os valores padrão. Essa validação estrutural não substitui uma captura de tráfego real entre o cliente v13 e o servidor; a equivalência final de wire format deve ser confirmada com payloads reais e os pseudocódigos do IDA.
