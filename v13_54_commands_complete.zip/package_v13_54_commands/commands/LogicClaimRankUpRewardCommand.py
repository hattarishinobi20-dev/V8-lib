from __future__ import annotations

from dataclasses import dataclass


@dataclass
class LogicClaimRankUpRewardCommand:
    """Command lógico interno v13; ID extraído de getCommandType no IDA."""

    id: int = 517

    @classmethod
    def get_command_type(cls) -> int:
        return cls.id

