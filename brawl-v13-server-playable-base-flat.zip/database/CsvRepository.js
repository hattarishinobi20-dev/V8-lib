const fs = require('fs')
const path = require('path')

function parseCsvLine (line) {
  const out = []
  let value = ''
  let quoted = false
  for (let i = 0; i < line.length; i += 1) {
    const ch = line[i]
    if (ch === '"') {
      if (quoted && line[i + 1] === '"') {
        value += '"'
        i += 1
      } else {
        quoted = !quoted
      }
    } else if (ch === ',' && !quoted) {
      out.push(value)
      value = ''
    } else {
      value += ch
    }
  }
  out.push(value)
  return out
}

function readCsv (file) {
  if (!fs.existsSync(file)) return []
  const lines = fs.readFileSync(file, 'utf8').replace(/^\ufeff/, '').split(/\r?\n/).filter(Boolean)
  if (!lines.length) return []
  const headers = parseCsvLine(lines[0]).map((x) => x.trim())
  return lines.slice(1).map((line) => {
    const values = parseCsvLine(line)
    return Object.fromEntries(headers.map((header, index) => [header, values[index] ?? '']))
  })
}

function toInt (value, fallback = 0) {
  const n = Number.parseInt(String(value ?? '').trim(), 10)
  return Number.isFinite(n) ? n : fallback
}

class CsvRepository {
  constructor (root = path.join(__dirname, '..', 'data', 'v13', 'csv_logic')) {
    this.root = root
    this.tables = new Map()
  }

  load (name) {
    if (!this.tables.has(name)) {
      this.tables.set(name, readCsv(path.join(this.root, name.endsWith('.csv') ? name : `${name}.csv`)))
    }
    return this.tables.get(name)
  }

  first (name, predicate = () => true) {
    return this.load(name).find(predicate) || null
  }

  byId (name, key = 'ID') {
    const map = new Map()
    for (const row of this.load(name)) map.set(toInt(row[key]), row)
    return map
  }

  summary () {
    const names = ['characters', 'cards', 'skins', 'maps', 'locations']
    return Object.fromEntries(names.map((name) => [name, this.load(name).length]))
  }
}

module.exports = { CsvRepository, readCsv, parseCsvLine, toInt }
