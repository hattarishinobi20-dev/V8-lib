from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high, x.low)

@dataclass
class HeroScoreEntry:
    value:int=0; global_id:DataReference=field(default_factory=DataReference)
    def encode(self,w:Writer)->None:w.write_vint(self.value);wr_ref(w,self.global_id)
    @classmethod
    def decode(cls,r:Reader):return cls(r.read_vint(),rd_ref(r))
@dataclass
class LogicDecreaseHeroScoreCommand:
    id:int=205; base_value_8:int=0; base_value_12:int=0; base_global_id:DataReference=field(default_factory=DataReference); tick_when_given:int=0; value_40:int=0; hero_score_entries:list[HeroScoreEntry]=field(default_factory=list)
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_int(self.value_40);w.write_vint(len(self.hero_score_entries))
        for x in self.hero_score_entries:x.encode(w)
        w.write_vint(self.tick_when_given);w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls();o.value_40=r.read_int();o.hero_score_entries=[HeroScoreEntry.decode(r) for _ in range(r.read_vint())];o.tick_when_given=r.read_vint();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);return o
