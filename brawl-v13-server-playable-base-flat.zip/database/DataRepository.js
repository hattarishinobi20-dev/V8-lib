const path = require('path')
const { CsvRepository, toInt } = require('./CsvRepository')

class DataRepository {
  constructor (root = path.join(__dirname, '..', 'data', 'v13', 'csv_logic')) {
    this.csv = new CsvRepository(root)
    this.characters = this.csv.load('characters')
    this.cards = this.csv.load('cards')
    this.skins = this.csv.load('skins')
    this.maps = this.csv.load('maps')
    this.locations = this.csv.load('locations')
    this.characterById = this.csv.byId('characters')
    this.cardById = this.csv.byId('cards')
    this.skinById = this.csv.byId('skins')
  }

  defaultBrawlers () {
    return this.characters.slice(0, 3).map((row, index) => ({
      id: toInt(row.ID, index),
      name: row.Name || row.Character || `Brawler${index}`,
      powerLevel: 1,
      trophies: 0,
      selected: index === 0
    }))
  }

  getMap (id = 0) {
    return this.maps.find((row) => toInt(row.ID) === id) || this.maps[0] || null
  }

  getCharacter (id) {
    return this.characterById.get(toInt(id)) || null
  }

  summary () {
    return {
      characters: this.characters.length,
      cards: this.cards.length,
      skins: this.skins.length,
      maps: this.maps.length,
      locations: this.locations.length
    }
  }
}

module.exports = DataRepository
