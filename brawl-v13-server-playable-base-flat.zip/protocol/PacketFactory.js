const MessageFactory = require('./MessageFactory')
const registry = require('./registry.json')

/**
 * Factory v13 sobre a MessageFactory original do nodebrawl-core.
 * O core continua fornecendo o contrato `packets`, `handle` e `getPackets`;
 * esta camada adiciona nomes, contexto, versões e criação inbound/outbound.
 */
class PacketFactory extends MessageFactory {
  constructor () {
    super({ autoLoad: false })
    this.byId = new Map()
    this.byName = new Map()

    for (const item of registry) {
      const Packet = require(`../messages/${item.role}/${item.name}`)
      const record = { ...item, Packet }
      this.packets[item.id] = Packet
      this.byId.set(item.id, record)
      this.byName.set(item.name, record)
    }
  }

  get (id) {
    return this.byId.get(Number(id)) || null
  }

  createInbound (id, payload, client, context) {
    const record = this.get(id)
    if (!record) return null
    return new record.Packet(payload, client, context)
  }

  createOutbound (name, client, context) {
    const record = this.byName.get(name)
    if (!record) throw new Error(`Packet desconhecido: ${name}`)
    return new record.Packet(client, context)
  }

  coverage () {
    return [...this.byId.values()].map(({ Packet, ...item }) => ({
      ...item,
      loaded: typeof Packet === 'function',
      coreRegistered: this.handle(item.id) === Packet
    }))
  }
}

module.exports = PacketFactory
