from Files.CsvLogic.Characters import Characters
from Files.CsvLogic.Skins import Skins
from Files.CsvLogic.Cards import Cards
from datetime import datetime
from Utils.Helpers import Helpers
from Utils.Writer import Writer
from Database.DatabaseManager import DataBase

from Logic.Shop import Shop
from Logic.EventSlots import EventSlots


class OwnHomeDataMessage(Writer):

    def __init__(self, client, player):
        super().__init__(client)
        self.id = 24101
        self.player = player

    def encode(self):
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(99999) # trophies
        self.writeVint(99999) # max trophies

        self.writeVint(0)
        self.writeVint(99) # Trophy road

        self.writeVint(0) # Player exp set

        self.writeScId(28, 0) # player icon

        self.writeVint(0) # array

        # Brawler skins array
        self.writeVint(999)
        for i in range(999):
            self.writeVint(29)
            self.writeVint(i)  # skinID

        # Unlocked Skins array
        self.writeVint(999)
        for i in range(999):
            self.writeScId(29, i)

        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)

        self.writeBoolean(False)

        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)

        self.writeVint(0)

        self.writeVint(1)
        self.writeVint(10)
        self.writeVint(20)
        self.writeVint(30)

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)

        self.writeScId(16, 0)
        
        self.writeVint(0)
        self.writeVint(99999) # tickets
        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(2019049)
        self.writeVint(100)
        self.writeVint(10)

        self.writeVint(30)
        self.writeVint(3)
        self.writeVint(80)

        self.writeVint(10)
        self.writeVint(50)
        self.writeVint(1000)

        self.writeVint(500)
        self.writeVint(50)
        self.writeVint(999900)

        self.writeVint(0)

        # 4 Gem Grab slots
        self.writeVint(10)
        for i in range(10):
            self.writeVint(i)

        self.writeVint(10)
        for i in range(10):
            self.writeVint(i)
            self.writeVint(i)
            self.writeVint(0)      # IsActive (0 = Active)
            self.writeVint(49020)  # timer
            self.writeVint(10)
            self.writeScId(15, 15)  #  map
            self.writeVint(3)
            self.writeString()
            self.writeVint(0)
            self.writeVint(1)
            self.writeVint(1)
            self.writeVint(0)

        self.writeVint(0)  # array

        self.writeVint(8)
        for i in [20, 35, 75, 140, 290, 480, 800, 1250]:
            self.writeVint(i)

        self.writeVint(8)
        for i in [1, 2, 3, 4, 5, 10, 15, 20]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [10, 30, 80]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [6, 20, 60]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [20, 50, 140]:
            self.writeVint(i)

        self.writeVint(3)
        for i in [150, 400, 1200]:
            self.writeVint(i)

        self.writeVint(0)
        self.writeVint(1337) # availabletokens
        self.writeVint(20)

        self.writeVint(8640)
        self.writeVint(10)
        self.writeVint(5)

        self.writeVint(6)

        self.writeVint(50)
        self.writeVint(604800)

        self.writeBoolean(True)

        self.writeVint(0) 

        self.writeVint(0)
        self.writeVint(0)

        self.writeVint(0)

        self.writeVint(0)

        self.writeVint(0)
        self.writeVint(0)

        for i in range(3):
            self.writeVint(0)
            self.writeVint(0)

        self.writeString("smwdev")  # Player Name
        self.writeVint(1)
        
        self.writeString()

        self.writeVint(8)

        # brawler info
        self.writeVint(128) # unlocked
        for x in range(124): # unlocked
            self.writeVint(23)
            self.writeVint(x)
            self.writeVint(1)

        self.writeScId(23, 0) # Select Brawler
        self.writeVint(1)

        self.writeScId(5, 1)
        self.writeVint(9999999) # Brawl Box

        self.writeScId(5, 8)
        self.writeVint(99999) # Coins

        self.writeScId(5, 9)
        self.writeVint(999999) # Big Box

        # brawler trophies
        self.writeVint(26)
        for i in range(26):
            self.writeScId(16, i)
            self.writeVint(99999)

        # brawler trophies for rank
        self.writeVint(26)
        for i in range(26):
            self.writeScId(16, i)
            self.writeVint(99999)

        self.writeVint(0)  # array

        # upgrade points
        self.writeVint(26)
        for i in range(26):
            self.writeScId(16, i)
            self.writeVint(1410)

        # power level
        self.writeVint(26)
        for i in range(26):
            self.writeScId(16, i)
            self.writeVint(9)

        self.writeVint(0)  # gadgets and starpowers
        self.writeVint(0)  # new brawler tag array

        self.writeVint(99999)  # gems
        self.writeVint(0)
        self.writeVint(1) # Player Experience
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(2) # tutorial state
        self.writeVint(1550832808)

        print("[INFO] Message OwnHomeData has been sent.")