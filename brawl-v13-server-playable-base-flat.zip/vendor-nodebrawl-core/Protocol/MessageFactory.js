const fs = require('fs')

class MessageFactory {
  constructor (options = {}) {
    this.packets = {}
    if (options.autoLoad !== false) this.loadClientMessages()
  }

  loadClientMessages () {
    fs.readdir('./Protocol/Messages/Client', (err, files) => {
      if (err) {
        console.log(err)
        return
      }
      files.forEach((file) => {
        try {
          const Packet = require(`./Messages/Client/${file.replace('.js', '')}`)
          const packetClass = new Packet()
          this.packets[packetClass.id] = Packet
        } catch (error) {
          console.log(`[SERVER] >> A wild error while initializing "${file.replace('.js', '')}" packet!`)
          console.log(error)
        }
      })
    })
  }

  handle (id) {
    return this.packets[id]
  }

  getPackets () {
    return Object.keys(this.packets)
  }
}

module.exports = MessageFactory
