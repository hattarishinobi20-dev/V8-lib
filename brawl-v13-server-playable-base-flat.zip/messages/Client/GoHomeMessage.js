const V13Message = require('../../protocol/V13Message')
const OwnHomeDataMessage = require('../Server/OwnHomeDataMessage')

class GoHomeMessage extends V13Message {
  constructor (bytes = null, client = null, context = null) {
    super(bytes, client, context)
    this.id = 14101
    this.version = 0
  }

  decode () { return this.decodeOpaque() }

  async process () {
    if (this.client.player) this.client.player.homeState = 'home'
    await new OwnHomeDataMessage(this.client, this.context).send()
    return this
  }
}

module.exports = GoHomeMessage
