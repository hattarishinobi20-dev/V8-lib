from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from common import Reader, Writer


@dataclass
class AddableFriendEntry:
    """Layout de AddableFriendEntry extraído de sub_3C678C/sub_49BBE4."""
    field_0: int = 0
    field_4: int = 0
    field_8: tuple[int, int] = (0, -1)
    field_12: int = 0
    field_16: int = 0
    field_20: int = 0
    field_24: int = 0
    field_28: int = 0
    field_36: tuple[int, int] = (0, -1)
    field_40: int = 0
    field_44: bool = False

    def encode(self, w: Writer) -> None:
        w.write_string(self.field_0)
        w.write_vint(self.field_4)
        w.write_data_reference(*self.field_8)
        w.write_vint(self.field_12)
        w.write_vint(self.field_16)
        w.write_vint(self.field_20)
        w.write_vint(self.field_24)
        w.write_data_reference(*self.field_36)
        w.write_vint(self.field_40)
        w.write_vint(self.field_28)
        w.write_boolean(self.field_44)

    @classmethod
    def decode(cls, r: Reader) -> AddableFriendEntry:
        return cls(
            field_0=r.read_string(), field_4=r.read_vint(), field_8=r.read_data_reference(),
            field_12=r.read_vint(), field_16=r.read_vint(), field_20=r.read_vint(),
            field_24=r.read_vint(), field_36=r.read_data_reference(), field_40=r.read_vint(),
            field_28=r.read_vint(), field_44=r.read_boolean(),
        )


@dataclass
class TypedStreamEntry:
    """Entrada polimórfica cujo type id e encode/decode são explicitamente preservados."""
    type_id: int = 0
    fields: list[Any] = field(default_factory=list)

    def encode(self, w: Writer) -> None:
        for value in self.fields:
            if isinstance(value, bool): w.write_boolean(value)
            elif isinstance(value, tuple) and len(value) == 2: w.write_data_reference(*value)
            elif isinstance(value, str) or value is None: w.write_string(value)
            else: w.write_vint(int(value))

    @classmethod
    def decode(cls, r: Reader, type_id: int) -> TypedStreamEntry:
        return cls(type_id=type_id, fields=[])


@dataclass
class LogicCompressedString:
    """Representação do objeto retornado por LogicCompressedString no pacote v13."""
    data: bytes = b""

    def encode(self, w: Writer) -> None:
        w.write_int(len(self.data))
        w.buf.extend(self.data)
        w._reset_bits()

    @classmethod
    def decode(cls, r: Reader) -> LogicCompressedString:
        n = r.read_int()
        return cls(b"" if n < 0 else r._take(n))
