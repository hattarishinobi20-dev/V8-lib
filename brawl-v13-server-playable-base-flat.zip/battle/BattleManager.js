const crypto = require('crypto')

class BattleManager {
  constructor (server) {
    this.server = server
    this.battles = new Map()
    this.queue = []
  }

  enqueue (player) {
    if (!this.queue.some((item) => item.id === player.id)) this.queue.push(player)
    if (this.queue.length >= 2) return this.start(this.queue.splice(0, 2))
    return null
  }

  start (players) {
    const battle = {
      id: crypto.randomBytes(4).toString('hex'),
      players,
      state: 'loading',
      result: 0,
      createdAt: Date.now(),
      startedAt: null,
      endedAt: null
    }
    this.battles.set(battle.id, battle)
    for (const player of players) {
      player.homeState = 'battle'
      player.battleId = battle.id
    }
    battle.state = 'started'
    battle.startedAt = Date.now()
    return battle
  }

  end (battleId, result = 0) {
    const battle = this.battles.get(String(battleId))
    if (!battle) return null
    battle.result = result
    battle.state = 'ended'
    battle.endedAt = Date.now()
    for (const player of battle.players) {
      player.addTrophies(result > 0 ? 8 : result < 0 ? -3 : 0)
      player.homeState = 'home'
      player.battleId = null
    }
    return battle
  }
}

module.exports = BattleManager
