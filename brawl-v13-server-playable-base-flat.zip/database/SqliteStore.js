const fs = require('fs')
const path = require('path')
const { DatabaseSync } = require('node:sqlite')

class SqliteStore {
  constructor (file = path.join(__dirname, '..', 'data', 'server.sqlite3')) {
    fs.mkdirSync(path.dirname(file), { recursive: true })
    this.file = file
    this.db = new DatabaseSync(file)
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA foreign_keys = ON;
      CREATE TABLE IF NOT EXISTS players (
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        trophies INTEGER NOT NULL DEFAULT 0,
        max_trophies INTEGER NOT NULL DEFAULT 0,
        gold INTEGER NOT NULL DEFAULT 1000,
        gems INTEGER NOT NULL DEFAULT 100,
        star_points INTEGER NOT NULL DEFAULT 0,
        tokens INTEGER NOT NULL DEFAULT 0,
        selected_brawler INTEGER NOT NULL DEFAULT 0,
        home_state TEXT NOT NULL DEFAULT 'home',
        created_at INTEGER NOT NULL,
        updated_at INTEGER NOT NULL
      );
      CREATE TABLE IF NOT EXISTS player_brawlers (
        player_id INTEGER NOT NULL,
        brawler_id INTEGER NOT NULL,
        name TEXT NOT NULL,
        power_level INTEGER NOT NULL DEFAULT 1,
        trophies INTEGER NOT NULL DEFAULT 0,
        selected INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (player_id, brawler_id),
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
      );
      CREATE TABLE IF NOT EXISTS player_skins (
        player_id INTEGER NOT NULL,
        skin_id INTEGER NOT NULL,
        PRIMARY KEY (player_id, skin_id),
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
      );
      CREATE TABLE IF NOT EXISTS sessions (
        token TEXT PRIMARY KEY,
        player_id INTEGER NOT NULL,
        created_at INTEGER NOT NULL,
        last_seen_at INTEGER NOT NULL,
        FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE
      );
    `)
    this.statements = {
      player: this.db.prepare('SELECT * FROM players WHERE id = ?'),
      brawlers: this.db.prepare('SELECT * FROM player_brawlers WHERE player_id = ? ORDER BY brawler_id'),
      skins: this.db.prepare('SELECT skin_id FROM player_skins WHERE player_id = ? ORDER BY skin_id'),
      session: this.db.prepare('SELECT player_id FROM sessions WHERE token = ?'),
      insertPlayer: this.db.prepare(`INSERT OR IGNORE INTO players (id, name, created_at, updated_at) VALUES (?, ?, ?, ?)`),
      updatePlayer: this.db.prepare(`UPDATE players SET name = ?, trophies = ?, max_trophies = ?, gold = ?, gems = ?, star_points = ?, tokens = ?, selected_brawler = ?, home_state = ?, updated_at = ? WHERE id = ?`),
      insertBrawler: this.db.prepare(`INSERT OR REPLACE INTO player_brawlers (player_id, brawler_id, name, power_level, trophies, selected) VALUES (?, ?, ?, ?, ?, ?)`),
      deleteSkins: this.db.prepare('DELETE FROM player_skins WHERE player_id = ?'),
      insertSkin: this.db.prepare('INSERT OR IGNORE INTO player_skins (player_id, skin_id) VALUES (?, ?)'),
      insertSession: this.db.prepare('INSERT OR REPLACE INTO sessions (token, player_id, created_at, last_seen_at) VALUES (?, ?, ?, ?)'),
      touchSession: this.db.prepare('UPDATE sessions SET last_seen_at = ? WHERE token = ?')
    }
  }

  loadPlayer (id) {
    const row = this.statements.player.get(Number(id))
    if (!row) return null
    return {
      ...row,
      brawlers: this.statements.brawlers.all(Number(id)),
      ownedSkins: this.statements.skins.all(Number(id)).map((item) => item.skin_id)
    }
  }

  ensurePlayer (player) {
    const now = Date.now()
    this.statements.insertPlayer.run(player.id, player.name, now, now)
    const saved = this.loadPlayer(player.id)
    if (saved) this.applySaved(player, saved)
    else this.savePlayer(player)
    if (!player.brawlers.length) {
      for (const brawler of player.brawlers) this.statements.insertBrawler.run(player.id, brawler.id, brawler.name, brawler.powerLevel, brawler.trophies, brawler.selected ? 1 : 0)
    }
    return player
  }

  applySaved (player, saved) {
    player.name = saved.name
    player.trophies = saved.trophies
    player.maxTrophies = saved.max_trophies
    player.gold = saved.gold
    player.gems = saved.gems
    player.starPoints = saved.star_points
    player.tokens = saved.tokens
    player.selectedBrawler = saved.selected_brawler
    player.homeState = saved.home_state
    if (saved.brawlers.length) {
      player.brawlers = saved.brawlers.map((row) => ({
        id: row.brawler_id,
        name: row.name,
        powerLevel: row.power_level,
        trophies: row.trophies,
        selected: Boolean(row.selected)
      }))
    }
    player.ownedSkins = saved.ownedSkins
  }

  savePlayer (player) {
    const now = Date.now()
    this.db.exec('BEGIN IMMEDIATE')
    try {
      this.statements.insertPlayer.run(player.id, player.name, now, now)
      this.statements.updatePlayer.run(player.name, player.trophies, player.maxTrophies, player.gold, player.gems, player.starPoints, player.tokens, player.selectedBrawler, player.homeState, now, player.id)
      for (const brawler of player.brawlers) this.statements.insertBrawler.run(player.id, brawler.id, brawler.name, brawler.powerLevel, brawler.trophies, brawler.selected ? 1 : 0)
      this.statements.deleteSkins.run(player.id)
      for (const skinId of player.ownedSkins) this.statements.insertSkin.run(player.id, skinId)
      this.db.exec('COMMIT')
    } catch (error) {
      this.db.exec('ROLLBACK')
      throw error
    }
  }

  saveSession (token, playerId) {
    const now = Date.now()
    this.statements.insertSession.run(token, Number(playerId), now, now)
  }

  playerIdFromSession (token) {
    if (!token) return null
    const row = this.statements.session.get(String(token))
    if (row) this.statements.touchSession.run(Date.now(), String(token))
    return row ? row.player_id : null
  }

  close () { this.db.close() }
}

module.exports = SqliteStore
