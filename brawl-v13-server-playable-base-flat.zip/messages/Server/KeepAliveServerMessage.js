const V13Message = require('../../protocol/V13Message')

class KeepAliveServerMessage extends V13Message {
  constructor (client = null, context = null) {
    super(null, client, context)
    this.id = 20108
    this.version = 0
  }

  encode () {
    // Codec confirmado no IDA: 0x688FCC / j_nullsub_34_27.
    // O layout completo está preservado em data/v13/ida_all_v13_codecs.json.
    return this.buffer
  }
}

module.exports = KeepAliveServerMessage
