// Exportação explícita da factory original do nodebrawl-core.
module.exports = require('../vendor-nodebrawl-core/Protocol/MessageFactory')
