from __future__ import annotations
import ast, importlib, json, sys
from pathlib import Path
root=Path('/home/ubuntu')
pkg=root/'ALL packets'
sys.path.insert(0,str(pkg))
sys.path.insert(0,str(pkg.parent))
contract=json.load(open(root/'v13_commands_compatibility_contract.json'))['commands']
fail=[]; placeholders=[]; imported=[]
for item in contract:
 name=item['name']; path=pkg/'commands'/f'{name}.py'
 if not path.exists():
  fail.append((name,'missing')); continue
 txt=path.read_text(errors='ignore')
 for term in ('CommandNestedObject','ByteStreamNotification','NotImplementedError','TODO','pass','object','return None'):
  if term in txt: placeholders.append((name,term))
 try:
  mod=importlib.import_module(f'commands.{name}')
  cls=getattr(mod,name)
  if getattr(cls,'id',None)!=item['id']: fail.append((name,f'id={getattr(cls,"id",None)} expected={item["id"]}'))
  obj=cls()
  data=obj.encode()
  decoded=cls.decode(data)
  imported.append(name)
 except Exception as e:
  fail.append((name,type(e).__name__+': '+str(e)))
print(json.dumps({'expected':54,'imported':len(imported),'failures':fail,'placeholders':placeholders,'ids_unique':len({x['id'] for x in contract})==54},indent=2,default=str))
