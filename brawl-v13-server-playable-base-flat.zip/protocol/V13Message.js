const V13ByteStream = require('./V13ByteStream')

class V13Message extends V13ByteStream {
  constructor (bytes = null, client = null, context = null) {
    super(bytes)
    this.client = client
    this.context = context || (client && client.server ? client.server.context : null)
    this.version = 0
    this._decoded = false
  }

  decodeOpaque () {
    this._decoded = true
    return this
  }

  dispatch () {
    if (this.client && this.client.server && this.client.server.router) {
      return this.client.server.router.handle(this)
    }
    return undefined
  }

  send () {
    if (!this.client) throw new Error(`${this.constructor.name} has no client`)
    this.offset = 0
    this.bitOffset = 0
    this.buffer = Buffer.alloc(0)
    this.encode()
    const payload = this.buffer.slice(0, this.offset)
    const header = Buffer.alloc(7)
    header.writeUInt16BE(this.id, 0)
    header.writeUIntBE(payload.length, 2, 3)
    header.writeUInt16BE(this.version || 0, 5)
    const trailer = Buffer.from([0xff, 0xff, 0, 0, 0, 0, 0])
    this.client.write(Buffer.concat([header, payload, trailer]))
    if (this.client.log) this.client.log(`Packet ${this.id} (${this.constructor.name}) was sent.`)
    return true
  }
}

module.exports = V13Message
