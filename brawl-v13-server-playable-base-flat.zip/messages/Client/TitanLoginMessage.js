const V13Message = require('../../protocol/V13Message')
const LoginOkMessage = require('../Server/LoginOkMessage')
const OwnHomeDataMessage = require('../Server/OwnHomeDataMessage')

class TitanLoginMessage extends V13Message {
  constructor (bytes = null, client = null, context = null) {
    super(bytes, client, context)
    this.id = 10101
    this.version = 0
  }

  decode () {
    // O codec v13 decompilado pelo IDA não lê campos neste packet.
    return this.decodeOpaque()
  }

  async process () {
    const server = this.client.server
    const playerId = this.client.playerId || server.nextPlayerId()
    const player = server.players.getOrCreate(playerId, `Player${playerId}`)
    const token = server.players.attach(player, this.client)
    this.client.player = player
    this.client.sessionToken = token
    await new LoginOkMessage(this.client, this.context).send()
    await new OwnHomeDataMessage(this.client, this.context).send()
    return this
  }
}

module.exports = TitanLoginMessage
