from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
from common import DataReference, Reader, Writer

def rd_ref(r: Reader) -> DataReference:
    h,l=r.read_data_reference(); return DataReference(h,l)
def wr_ref(w: Writer, x: DataReference) -> None:
    w.write_data_reference(x.high, x.low)

@dataclass
class IAPState:
    global_id:DataReference=field(default_factory=DataReference); value_4:int=0; value_8:int=0
    def encode(self,w:Writer)->None:wr_ref(w,self.global_id);w.write_int(self.value_4);w.write_int(self.value_8)
    @classmethod
    def decode(cls,r:Reader):return cls(rd_ref(r),r.read_int(),r.read_int())
@dataclass
class LogicIAPChangedCommand:
    id:int=210;base_value_8:int=0;base_value_12:int=0;base_global_id:DataReference=field(default_factory=DataReference);value_28:int=0;iap:Optional[IAPState]=None
    @classmethod
    def get_command_type(cls)->int:return cls.id
    def encode(self)->bytes:
        w=Writer();w.write_vint(self.base_value_12);w.write_vint(self.base_value_8);wr_ref(w,self.base_global_id);w.write_vint(self.value_28);w.write_boolean(self.iap is not None);
        if self.iap:self.iap.encode(w)
        return w.bytes()
    @classmethod
    def decode(cls,payload:bytes):
        r=Reader(payload);o=cls();o.base_value_12=r.read_vint();o.base_value_8=r.read_vint();o.base_global_id=rd_ref(r);o.value_28=r.read_vint();o.iap=IAPState.decode(r) if r.read_boolean() else None;return o
