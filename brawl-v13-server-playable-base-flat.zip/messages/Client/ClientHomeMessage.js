// Compatibilidade de nomenclatura para o fluxo solicitado.
// No inventário v13 do IDA, o pacote de retorno à home é GoHomeMessage (14101).
module.exports = require('./GoHomeMessage')
