from __future__ import annotations

# Registro canônico dos 54 commands extraídos do libv13.so.i64.

from .LogicChangeAvatarNameCommand import LogicChangeAvatarNameCommand
from .LogicDiamondsAddedCommand import LogicDiamondsAddedCommand
from .LogicGiveDeliveryItemsCommand import LogicGiveDeliveryItemsCommand
from .LogicDayChangedCommand import LogicDayChangedCommand
from .LogicDecreaseHeroScoreCommand import LogicDecreaseHeroScoreCommand
from .LogicAddNotificationCommand import LogicAddNotificationCommand
from .LogicChangeResourcesCommand import LogicChangeResourcesCommand
from .LogicTransactionsRevokedCommand import LogicTransactionsRevokedCommand
from .LogicKeyPoolChangedCommand import LogicKeyPoolChangedCommand
from .LogicIAPChangedCommand import LogicIAPChangedCommand
from .LogicOffersChangedCommand import LogicOffersChangedCommand
from .LogicPlayerDataChangedCommand import LogicPlayerDataChangedCommand
from .LogicInviteBlockingChangedCommand import LogicInviteBlockingChangedCommand
from .LogicGemNameChangeStateChangedCommand import LogicGemNameChangeStateChangedCommand
from .LogicSetSupportedCreatorCommand import LogicSetSupportedCreatorCommand
from .LogicCooldownExpiredCommand import LogicCooldownExpiredCommand
from .LogicProLeagueSeasonChangedCommand import LogicProLeagueSeasonChangedCommand
from .LogicBrawlPassSeasonChangedCommand import LogicBrawlPassSeasonChangedCommand
from .LogicBrawlPassUnlockedCommand import LogicBrawlPassUnlockedCommand
from .LogicHeroWinQuestsChangedCommand import LogicHeroWinQuestsChangedCommand
from .LogicTeamChatMuteStateChangedCommand import LogicTeamChatMuteStateChangedCommand
from .LogicGatchaCommand import LogicGatchaCommand
from .LogicClaimDailyRewardCommand import LogicClaimDailyRewardCommand
from .LogicSendAllianceMailCommand import LogicSendAllianceMailCommand
from .LogicSetPlayerThumbnailCommand import LogicSetPlayerThumbnailCommand
from .LogicSelectSkinCommand import LogicSelectSkinCommand
from .LogicUnlockSkinCommand import LogicUnlockSkinCommand
from .LogicChangeControlModeCommand import LogicChangeControlModeCommand
from .LogicPurchaseDoubleCoinsCommand import LogicPurchaseDoubleCoinsCommand
from .LogicHelpOpenedCommand import LogicHelpOpenedCommand
from .LogicToggleInGameHintsCommand import LogicToggleInGameHintsCommand
from .LogicDeleteNotificationCommand import LogicDeleteNotificationCommand
from .LogicClearShopTickersCommand import LogicClearShopTickersCommand
from .LogicPurchaseOfferCommand import LogicPurchaseOfferCommand
from .LogicLevelUpCommand import LogicLevelUpCommand
from .LogicPurchaseHeroLvlUpMaterialCommand import LogicPurchaseHeroLvlUpMaterialCommand
from .LogicHeroSeenCommand import LogicHeroSeenCommand
from .LogicClaimAdRewardCommand import LogicClaimAdRewardCommand
from .LogicVideoStartedCommand import LogicVideoStartedCommand
from .LogicSelectCharacterCommand import LogicSelectCharacterCommand
from .LogicUnlockFreeSkinsCommand import LogicUnlockFreeSkinsCommand
from .LogicSetPlayerNameColorCommand import LogicSetPlayerNameColorCommand
from .LogicViewInboxNotificationCommand import LogicViewInboxNotificationCommand
from .LogicSelectStarPowerCommand import LogicSelectStarPowerCommand
from .LogicSetPlayerAgeCommand import LogicSetPlayerAgeCommand
from .LogicCancelPurchaseOfferCommand import LogicCancelPurchaseOfferCommand
from .LogicItemSeenCommand import LogicItemSeenCommand
from .LogicQuestsSeenCommand import LogicQuestsSeenCommand
from .LogicPurchaseBrawlPassCommand import LogicPurchaseBrawlPassCommand
from .LogicClaimTailRewardCommand import LogicClaimTailRewardCommand
from .LogicPurchaseBrawlPassProgressCommand import LogicPurchaseBrawlPassProgressCommand
from .LogicVanityItemSeenCommand import LogicVanityItemSeenCommand
from .LogicSelectEmoteCommand import LogicSelectEmoteCommand
from .LogicDebugCommand import LogicDebugCommand

COMMANDS_BY_ID = {
    201: LogicChangeAvatarNameCommand,
    202: LogicDiamondsAddedCommand,
    203: LogicGiveDeliveryItemsCommand,
    204: LogicDayChangedCommand,
    205: LogicDecreaseHeroScoreCommand,
    206: LogicAddNotificationCommand,
    207: LogicChangeResourcesCommand,
    208: LogicTransactionsRevokedCommand,
    209: LogicKeyPoolChangedCommand,
    210: LogicIAPChangedCommand,
    211: LogicOffersChangedCommand,
    212: LogicPlayerDataChangedCommand,
    213: LogicInviteBlockingChangedCommand,
    214: LogicGemNameChangeStateChangedCommand,
    215: LogicSetSupportedCreatorCommand,
    216: LogicCooldownExpiredCommand,
    217: LogicProLeagueSeasonChangedCommand,
    218: LogicBrawlPassSeasonChangedCommand,
    219: LogicBrawlPassUnlockedCommand,
    220: LogicHeroWinQuestsChangedCommand,
    221: LogicTeamChatMuteStateChangedCommand,
    500: LogicGatchaCommand,
    503: LogicClaimDailyRewardCommand,
    504: LogicSendAllianceMailCommand,
    505: LogicSetPlayerThumbnailCommand,
    506: LogicSelectSkinCommand,
    507: LogicUnlockSkinCommand,
    508: LogicChangeControlModeCommand,
    509: LogicPurchaseDoubleCoinsCommand,
    511: LogicHelpOpenedCommand,
    512: LogicToggleInGameHintsCommand,
    514: LogicDeleteNotificationCommand,
    515: LogicClearShopTickersCommand,
    519: LogicPurchaseOfferCommand,
    520: LogicLevelUpCommand,
    521: LogicPurchaseHeroLvlUpMaterialCommand,
    522: LogicHeroSeenCommand,
    523: LogicClaimAdRewardCommand,
    524: LogicVideoStartedCommand,
    525: LogicSelectCharacterCommand,
    526: LogicUnlockFreeSkinsCommand,
    527: LogicSetPlayerNameColorCommand,
    528: LogicViewInboxNotificationCommand,
    529: LogicSelectStarPowerCommand,
    530: LogicSetPlayerAgeCommand,
    531: LogicCancelPurchaseOfferCommand,
    532: LogicItemSeenCommand,
    533: LogicQuestsSeenCommand,
    534: LogicPurchaseBrawlPassCommand,
    535: LogicClaimTailRewardCommand,
    536: LogicPurchaseBrawlPassProgressCommand,
    537: LogicVanityItemSeenCommand,
    538: LogicSelectEmoteCommand,
    1000: LogicDebugCommand,
}

COMMAND_NAMES_BY_ID = {
    201: 'LogicChangeAvatarNameCommand',
    202: 'LogicDiamondsAddedCommand',
    203: 'LogicGiveDeliveryItemsCommand',
    204: 'LogicDayChangedCommand',
    205: 'LogicDecreaseHeroScoreCommand',
    206: 'LogicAddNotificationCommand',
    207: 'LogicChangeResourcesCommand',
    208: 'LogicTransactionsRevokedCommand',
    209: 'LogicKeyPoolChangedCommand',
    210: 'LogicIAPChangedCommand',
    211: 'LogicOffersChangedCommand',
    212: 'LogicPlayerDataChangedCommand',
    213: 'LogicInviteBlockingChangedCommand',
    214: 'LogicGemNameChangeStateChangedCommand',
    215: 'LogicSetSupportedCreatorCommand',
    216: 'LogicCooldownExpiredCommand',
    217: 'LogicProLeagueSeasonChangedCommand',
    218: 'LogicBrawlPassSeasonChangedCommand',
    219: 'LogicBrawlPassUnlockedCommand',
    220: 'LogicHeroWinQuestsChangedCommand',
    221: 'LogicTeamChatMuteStateChangedCommand',
    500: 'LogicGatchaCommand',
    503: 'LogicClaimDailyRewardCommand',
    504: 'LogicSendAllianceMailCommand',
    505: 'LogicSetPlayerThumbnailCommand',
    506: 'LogicSelectSkinCommand',
    507: 'LogicUnlockSkinCommand',
    508: 'LogicChangeControlModeCommand',
    509: 'LogicPurchaseDoubleCoinsCommand',
    511: 'LogicHelpOpenedCommand',
    512: 'LogicToggleInGameHintsCommand',
    514: 'LogicDeleteNotificationCommand',
    515: 'LogicClearShopTickersCommand',
    519: 'LogicPurchaseOfferCommand',
    520: 'LogicLevelUpCommand',
    521: 'LogicPurchaseHeroLvlUpMaterialCommand',
    522: 'LogicHeroSeenCommand',
    523: 'LogicClaimAdRewardCommand',
    524: 'LogicVideoStartedCommand',
    525: 'LogicSelectCharacterCommand',
    526: 'LogicUnlockFreeSkinsCommand',
    527: 'LogicSetPlayerNameColorCommand',
    528: 'LogicViewInboxNotificationCommand',
    529: 'LogicSelectStarPowerCommand',
    530: 'LogicSetPlayerAgeCommand',
    531: 'LogicCancelPurchaseOfferCommand',
    532: 'LogicItemSeenCommand',
    533: 'LogicQuestsSeenCommand',
    534: 'LogicPurchaseBrawlPassCommand',
    535: 'LogicClaimTailRewardCommand',
    536: 'LogicPurchaseBrawlPassProgressCommand',
    537: 'LogicVanityItemSeenCommand',
    538: 'LogicSelectEmoteCommand',
    1000: 'LogicDebugCommand',
}

def get_command_class(command_id: int):
    return COMMANDS_BY_ID.get(command_id)

def get_command_ids() -> tuple[int, ...]:
    return tuple(sorted(COMMANDS_BY_ID))
