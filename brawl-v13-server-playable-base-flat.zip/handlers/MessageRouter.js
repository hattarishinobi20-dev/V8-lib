class MessageRouter {
  constructor (server) {
    this.server = server
    this.handlers = new Map()
    this.handlers.set('ClientHelloMessage', (message) => message.process())
    this.handlers.set('TitanLoginMessage', (message) => message.process())
    this.handlers.set('GoHomeMessage', (message) => message.process())
  }

  async handle (message) {
    const handler = this.handlers.get(message.constructor.name)
    if (handler) return handler(message)
    this.server.log.debug(`Packet ${message.id} (${message.constructor.name}) recebido sem handler na base mínima`)
    return null
  }
}

module.exports = MessageRouter
