# Auditoria do estado atual

## Resultado

O registry contém 281 IDs. Existem 277 arquivos de mensagens porque algumas classes especiais não foram geradas automaticamente e foram escritas manualmente. A busca por marcadores de geração encontrou 272 arquivos com wrappers genéricos ou retornos de buffer sem codec completo.

## Persistência

O projeto possui `CsvRepository.js` e `DataRepository.js`, mas não possui ainda uma database persistente de jogadores. `PlayerStore.js` mantém jogadores e sessões somente em memória; reiniciar o processo perde perfil, troféus, recursos, brawlers, skins e tokens.

## Uso do core

O projeto importa `ByteStream` e `PiranhaMessage` do clone local do `nodebrawl-core`, e implementa uma camada de conexão/framing derivada do socket do core. Ainda faltam testes que provem compatibilidade byte a byte com o transporte e com as mensagens reais do core.

## Codecs

O IDA produziu um catálogo de pseudocódigo para os 281 IDs, mas apenas um subconjunto de mensagens centrais tem implementação manual. A maioria das classes preserva o ID e o nome, porém não traduz as chamadas de `encode`/`decode` do IDA para operações concretas do `ByteStream`.

## Conclusão

O estado atual não deve ser apresentado como servidor v13 completo. As próximas etapas obrigatórias são adicionar persistência, traduzir codecs com operações comprovadas, cobrir as classes ausentes e criar testes de framing, registry, login, home e persistência.
